'use strict';
/* Luật chơi chạy trên SERVER: vàng, hạng, mưa vàng, nhiệm vụ, skin, code. App chỉ hiển thị kết quả server trả về. */
const crypto = require('crypto');

const ROUND_MS = 60 * 1000, LOCK_MS = 10 * 1000, RED_MAX = 10;
const MIN_STAKE = 1, MAX_STAKE = 1000, STAR_PRICE = 80, RAIN_BONUS = 50;
const VN_OFFSET = 7 * 3600 * 1000;

const RANKS = [
    { name: 'Tân binh', min: 0, mult: 1.0 }, { name: 'Đồng', min: 50, mult: 1.2 }, { name: 'Bạc', min: 88, mult: 1.3 },
    { name: 'Vàng', min: 175, mult: 1.4 }, { name: 'Kim cương', min: 438, mult: 1.5 }, { name: 'Cao thủ', min: 493, mult: 5.0 }
];
const LOSS_FRAC = [0.50, 0.56, 0.62, 0.68, 0.74, 0.80];
const RAIN_BY_RANK = [
    { step: 0.061, grace: 0, cap: 0.30, pmax: 11 }, { step: 0.028, grace: 0, cap: 0.27, pmax: 12 },
    { step: 0.021, grace: 0, cap: 0.26, pmax: 13 }, { step: 0.019, grace: 0, cap: 0.25, pmax: 14 },
    { step: 0.061, grace: 4, cap: 0.30, pmax: 15 }, { step: 0.026, grace: 0, cap: 0.10, pmax: 20 }
];
const DAILY_REWARDS = [10, 15, 20, 25, 30, 40, 80];
const MISSIONS = [
    { id: 'd_play', scope: 'day', stat: 'plays', goal: 10, gold: 15 },
    { id: 'd_win', scope: 'day', stat: 'wins', goal: 5, gold: 20 },
    { id: 'd_str', scope: 'day', stat: 'streak', goal: 3, gold: 25 },
    { id: 'w_play', scope: 'week', stat: 'plays', goal: 60, gold: 80 },
    { id: 'w_win', scope: 'week', stat: 'wins', goal: 30, gold: 100 }
];
const SKINS = { classic: 0, ruby: 60, emerald: 100, ice: 140, sakura: 180, gold: 250, obsidian: 350, neon: 500, rainbow: 'rain3', legend: 'login7' };
const ACHS = [
    { id: 'first_win', test: (p) => p.correct >= 1 }, { id: 'win10', test: (p) => p.correct >= 10 },
    { id: 'win100', test: (p) => p.correct >= 100 }, { id: 'streak5', test: (p) => p.best >= 5 },
    { id: 'streak10', test: (p) => p.best >= 10 }, { id: 'silver', test: (p) => rankIndex(p.profit) >= 2 },
    { id: 'rain3', test: (p) => (p.rainTotal || 0) >= 3, skin: 'rainbow' },
    { id: 'login7', test: (p) => p.daily && p.daily.best >= 7, skin: 'legend' }
];
const ACH_NAMES = { rain3: 'Mưa vàng 3 lần', login7: 'Điểm danh 7 ngày liền' };
// Code thử: dùng không giới hạn trừ khi có "once". Đặt DISABLE_TEST_CODES=1 để tắt hẳn trước khi phát hành.
const CODES = process.env.DISABLE_TEST_CODES === '1' ? {} : {
    test: { gold: 10 }, nocode: { gold: -10 },
    newbie100: { gold: 100, once: true, id: 'newbie' }, newbie: { gold: 100, once: true, id: 'newbie' }
};

class GameError extends Error { constructor(msg) { super(msg); this.status = 400; } }

const rankIndex = (profit) => { let i = 0; RANKS.forEach((r, n) => { if (profit >= r.min) i = n; }); return i; };
const rand = () => crypto.randomInt(1e9) / 1e9;
const vnDate = (ms) => new Date(ms + VN_OFFSET);
const dayKey = (ms) => vnDate(ms).toISOString().slice(0, 10);
const weekKey = (ms) => { const d = vnDate(ms); const dow = (d.getUTCDay() + 6) % 7; return new Date(d.getTime() - dow * 86400000).toISOString().slice(0, 10); };
const evMult = (ms) => { const d = vnDate(ms), dow = d.getUTCDay(), h = d.getUTCHours(); return (dow === 6 || dow === 0) && h >= 20 && h < 22 ? 1.5 : 1; };
const rainChance = (ri, n) => { const r = RAIN_BY_RANK[ri]; return n >= r.pmax ? 1 : Math.min(r.cap, Math.max(0, r.step * (n - r.grace))); };
const colorOfSum = (s) => (s <= RED_MAX ? 'RED' : 'GREEN');

function newState(gold) {
    return {
        v: 1, wallet: gold, profit: 0, streak: 0, best: 0, correct: 0, total: 0, rainCount: 0, rainTotal: 0,
        owned: ['classic'], skin: 'classic', usedCodes: {}, daily: { last: '', streak: 0, best: 0 },
        mday: null, mweek: null, ach: {}, pend: [], log: []
    };
}
function ensure(p, now) {
    const dk = dayKey(now), wk = weekKey(now);
    if (!p.mday || p.mday.key !== dk) p.mday = { key: dk, plays: 0, wins: 0, streak: 0, claimed: {} };
    if (!p.mweek || p.mweek.key !== wk) p.mweek = { key: wk, plays: 0, wins: 0, claimed: {} };
}
const reserved = (p, except) => p.pend.reduce((s, e) => s + (e === except ? 0 : e.stake), 0);

function checkAch(p, events) {
    ACHS.forEach((a) => {
        if (p.ach[a.id] || !a.test(p)) return;
        p.ach[a.id] = Date.now();
        if (a.skin && !p.owned.includes(a.skin)) p.owned.push(a.skin);
        events.push(`🏆 Thành tựu mới${a.skin ? ': mở khóa skin ' + a.skin : ''}`);
    });
}

// Chấm mọi lựa chọn của các ván đã kết thúc (k < cur). dice(room,k) → [x1,x2,x3]. onWin(): đếm bảng xếp hạng tuần.
function settle(p, cur, dice, now, onWin) {
    ensure(p, now);
    const outcomes = [];
    p.pend.sort((a, b) => a.k - b.k);
    const keep = [];
    for (const e of p.pend) {
        if (e.k >= cur) { keep.push(e); continue; }
        const d = dice(e.room, e.k), sum = d[0] + d[1] + d[2];
        const before = rankIndex(p.profit);
        const win = e.color === colorOfSum(sum);
        let gain = 0, loss = 0, rain = 0;
        p.total++; p.mday.plays++; p.mweek.plays++;
        if (win) {
            gain = Math.round(e.stake * RANKS[before].mult * evMult((e.k + 1) * ROUND_MS));
            p.wallet += gain;
            p.rainCount = (p.rainCount || 0) + 1;
            if (rand() < rainChance(before, p.rainCount)) { rain = RAIN_BONUS; p.wallet += rain; p.rainCount = 0; p.rainTotal++; }
            p.profit += gain + rain;
            p.correct++; p.streak++; p.best = Math.max(p.best, p.streak);
            p.mday.wins++; p.mweek.wins++; p.mday.streak = Math.max(p.mday.streak, p.streak);
            if (onWin) onWin();
        } else {
            p.streak = 0;
            loss = Math.max(0, Math.min(Math.max(1, Math.round(e.stake * LOSS_FRAC[before])), p.wallet));
            p.wallet -= loss;
            p.profit = Math.max(0, p.profit - loss);
        }
        const after = rankIndex(p.profit);
        p.log.push({ room: e.room, k: e.k, color: e.color, stake: e.stake });
        outcomes.push({ k: e.k, room: e.room, picked: e.color, win, stake: e.stake, gain, loss, rain, rankUp: after > before ? after : null, rankDown: after < before ? after : null, sum });
    }
    p.pend = keep;
    if (p.log.length > 80) p.log = p.log.slice(-80);
    // số dư không còn đủ cho mức cược đang chờ → huỷ lựa chọn đó
    p.pend = p.pend.filter((e) => p.wallet >= e.stake);
    const events = [];
    checkAch(p, events);
    return { outcomes, events };
}

// color = 'RED' | 'GREEN' | null (bỏ chọn)
function pick(p, room, cur, color, stake, now) {
    ensure(p, now);
    const remain = (cur + 1) * ROUND_MS - now;
    if (remain <= LOCK_MS) throw new GameError('Ván đã khoá, không đổi lựa chọn được.');
    const same = p.pend.find((e) => e.k === cur && e.room === room);
    if (color === null) { p.pend = p.pend.filter((e) => e !== same); return; }
    if (color !== 'RED' && color !== 'GREEN') throw new GameError('Màu không hợp lệ.');
    if (!Number.isInteger(stake) || stake < MIN_STAKE || stake > MAX_STAKE) throw new GameError(`Mức cược từ ${MIN_STAKE} đến ${MAX_STAKE}.`);
    if (stake > p.wallet - reserved(p, same)) throw new GameError('Không thể cược quá số dư.');
    if (same) { same.color = color; same.stake = stake; } else p.pend.push({ room, k: cur, color, stake });
}

function claimDaily(p, now) {
    ensure(p, now);
    const today = dayKey(now), yest = dayKey(now - 86400000), dl = p.daily;
    if (dl.last === today) throw new GameError('Hôm nay bạn đã điểm danh rồi.');
    const alive = dl.last === yest;
    dl.streak = (alive ? dl.streak : 0) + 1;
    dl.best = Math.max(dl.best || 0, dl.streak);
    dl.last = today;
    const gold = DAILY_REWARDS[(dl.streak - 1) % 7];
    p.wallet += gold;
    const events = [`📅 Điểm danh ngày ${dl.streak}: +${gold} vàng`];
    checkAch(p, events);
    return events;
}
function claimMission(p, id, now) {
    ensure(p, now);
    const m = MISSIONS.find((x) => x.id === id);
    if (!m) throw new GameError('Nhiệm vụ không tồn tại.');
    const box = m.scope === 'day' ? p.mday : p.mweek;
    if (box.claimed[id]) throw new GameError('Đã nhận rồi.');
    if ((box[m.stat] || 0) < m.goal) throw new GameError('Chưa hoàn thành nhiệm vụ.');
    box.claimed[id] = true;
    p.wallet += m.gold;
    return [`🎯 Hoàn thành nhiệm vụ: +${m.gold} vàng`];
}
function useSkin(p, id) {
    if (!Object.prototype.hasOwnProperty.call(SKINS, id)) throw new GameError('Skin không tồn tại.');
    const price = SKINS[id];
    if (p.owned.includes(id)) { p.skin = id; return; }
    if (typeof price !== 'number') throw new GameError('Skin sự kiện chỉ nhận được khi mở khóa thành tựu.');
    if (p.wallet - reserved(p, null) < price) throw new GameError('Không đủ vàng.');
    p.wallet -= price; p.owned.push(id); p.skin = id;
}
function redeemCode(p, key) {
    key = String(key || '').trim().toLowerCase().replace(/\s+/g, '');
    if (!Object.prototype.hasOwnProperty.call(CODES, key)) throw new GameError('Code không hợp lệ.');
    const c = CODES[key];
    if (c.once && p.usedCodes[c.id]) throw new GameError('Code này đã được sử dụng (mỗi code chỉ dùng 1 lần).');
    const before = p.wallet;
    p.wallet = Math.max(0, p.wallet + c.gold);
    if (c.once) p.usedCodes[c.id] = true;
    p.pend = p.pend.filter((e) => p.wallet >= e.stake);
    return p.wallet - before;
}
// Trừ vàng khi mua sao (server cộng sao riêng)
function spendForStars(p, qty) {
    const cost = qty * STAR_PRICE;
    if (p.wallet - reserved(p, null) < cost) throw new GameError('Không đủ vàng.');
    p.wallet -= cost;
}

// Dữ liệu gửi cho app (phần của phòng đang chơi)
function view(p, room) {
    const picks = {}, stakes = {}, resolved = {};
    p.log.forEach((e) => { if (e.room === room) { picks[e.k] = e.color; stakes[e.k] = e.stake; resolved[e.k] = true; } });
    p.pend.forEach((e) => { if (e.room === room) { picks[e.k] = e.color; stakes[e.k] = e.stake; } });
    const r = reserved(p, null);
    return {
        wallet: p.wallet, reserved: r, profit: p.profit, streak: p.streak, best: p.best, correct: p.correct, total: p.total,
        rainCount: p.rainCount, rainTotal: p.rainTotal, owned: p.owned, skin: p.skin, daily: p.daily, mday: p.mday, mweek: p.mweek,
        ach: p.ach, picks, stakes, resolved
    };
}

module.exports = {
    ROUND_MS, LOCK_MS, STAR_PRICE, GameError, newState, ensure, settle, pick, claimDaily, claimMission, useSkin, redeemCode, spendForStars, view,
    rankIndex, colorOfSum, CODES
};
