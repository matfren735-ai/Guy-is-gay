# Đưa game lên mạng (link `guyisgayy`)

Server là một ứng dụng Node (>= 22.5) kèm file SQLite, nên cần chỗ chạy có **ổ đĩa lưu dữ liệu**.
Nếu không có ổ đĩa, mỗi lần khởi động lại sẽ mất toàn bộ tài khoản và code.

## Cách 1: Render (dễ nhất, ~7 USD/tháng vì cần ổ đĩa)
1. Tạo tài khoản GitHub, tạo repo mới, tải thư mục `xucxac-server` lên (có sẵn `Dockerfile`, `render.yaml`).
2. Vào render.com > New > Blueprint > chọn repo. Render đọc `render.yaml` và tự dựng.
3. Đặt tên dịch vụ `guyisgayy` thì link sẽ là `https://guyisgayy.onrender.com`
   (nếu tên đã có người dùng, Render sẽ thêm hậu tố ngẫu nhiên).

## Cách 2: Fly.io hoặc Railway
Cùng `Dockerfile`, gắn volume vào `/data`, đặt `TRUST_PROXY=1`.

## Cách 3: VPS (rẻ nhất khi lớn)
```
git clone <repo> && cd xucxac-server
docker build -t xucxac .
docker run -d --restart=always -p 3000:3000 -v xucxac-data:/data \
  -e PUBLIC_URL=https://guyisgayy.duckdns.org -e CONTACT_EMAIL=email-cua-ban@gmail.com xucxac
```
Đặt Caddy hoặc Nginx phía trước để có https.

## Dùng tên miền riêng, ví dụ `guyisgayy.com`
1. Mua tên miền (Namecheap, Porkbun, khoảng 10 USD/năm). Tên miền Việt `.vn` cần giấy tờ.
2. Trong trang quản lý dịch vụ (Render: Settings > Custom Domains) thêm tên miền đó.
3. Ở nơi mua tên miền, tạo bản ghi DNS (CNAME) theo đúng hướng dẫn dịch vụ hiển thị.
4. Chờ vài phút đến vài giờ, https tự bật.

## Kiểm tra
- Mở `https://<link của bạn>/healthz` phải thấy `ok`.
- Mở link gốc phải ra game, đăng ký tài khoản được.

## Trước khi công khai
- Xóa code thử `test`, `nocode` trong game (biến `CODES`).
- Sao lưu file `/data/data.sqlite` định kỳ.
- Gold và kết quả vòng vẫn chạy trên máy người chơi nên có thể bị gian lận; đây là phần cần làm tiếp nếu bạn muốn nghiêm túc.

## Email: quên mật khẩu, thu thập thông tin, bán gói tháng
Game giờ bắt người đăng ký nhập email (để lấy lại mật khẩu) và có ô tích tùy chọn "nhận ưu đãi/gói tháng".

**Biến môi trường (đặt khi chạy server)**
| Biến | Ý nghĩa |
|---|---|
| `PUBLIC_URL` | Địa chỉ công khai của game, dùng làm link trong thư đặt lại mật khẩu. **Bắt buộc đặt đúng.** |
| `CONTACT_EMAIL` | Email liên hệ hiện trong trang Điều khoản và Chính sách bảo mật |
| `SITE_NAME` | Tên hiện trong thư và trang pháp lý |
| `MAIL_FROM` + `BREVO_API_KEY` | Gửi thư qua Brevo (gói miễn phí khoảng 300 thư/ngày, gửi được từ một email đã xác minh, không cần tên miền riêng) |
| `MAIL_FROM` + `RESEND_API_KEY` | Hoặc gửi qua Resend (cần tên miền riêng đã xác minh) |

Chưa đặt `MAIL_FROM` và khoá API thì thư **chỉ in ra nhật ký server** (`docker logs xucxac`), người dùng sẽ không nhận được gì. Muốn tính năng quên mật khẩu hoạt động thật, bạn phải cấu hình một trong hai.
Cách làm với Brevo: đăng ký brevo.com, vào Senders để xác minh email gửi, tạo API key (SMTP & API), rồi chạy lại container với `-e MAIL_FROM=... -e BREVO_API_KEY=...`. Thư có thể rơi vào mục thư rác nếu gửi từ Gmail cá nhân, nên về lâu dài nên dùng tên miền riêng.

**Lấy danh sách email để bán gói tháng**
```
sudo docker exec xucxac node export-emails.js > emails.csv        # chỉ người đã tích đồng ý nhận ưu đãi
sudo docker exec xucxac node export-emails.js --all > tat-ca.csv  # tất cả (chỉ dùng gửi thư dịch vụ)
```
Chỉ gửi quảng bá cho người đã tích đồng ý, và mỗi thư quảng bá phải có cách hủy nhận. Nhiều nơi (Canada có luật CASL, EU có GDPR, Mỹ có CAN-SPAM) phạt nặng gửi thư rác. Hai trang `/terms` và `/privacy` là bản mẫu, bạn nên nhờ luật sư rà lại.

## Bảo vệ tài khoản (đã có sẵn)
- Mật khẩu băm scrypt, tối thiểu 8 ký tự, từ chối mật khẩu quá dễ đoán.
- Sai mật khẩu 5 lần thì khóa tài khoản 15 phút; giới hạn số lần đăng nhập, đăng ký, quên mật khẩu theo IP và theo email.
- Link đặt lại mật khẩu: dùng 1 lần, hết hạn sau 30 phút, chỉ lưu bản băm; đặt lại xong mọi thiết bị bị đăng xuất.
- Đổi mật khẩu hoặc email cần nhập mật khẩu hiện tại. Người dùng tự xóa được tài khoản.
- Việc cần bạn làm: dùng https (Caddy ở trên), sao lưu file `data.sqlite`, giữ kín khóa API gửi thư.

## Xác minh email khi đăng ký (bắt buộc)
Đăng ký xong, người chơi phải nhập mã 6 số gửi tới email mới dùng được tài khoản (mã hiệu lực 15 phút, nhập sai quá 5 lần phải xin mã mới, tài khoản chưa xác minh bị xóa sau 24 giờ).
- **Muốn gửi thư thật:** cấu hình `MAIL_FROM` + `BREVO_API_KEY` (xem mục Email ở trên).
- **Chưa cấu hình thư:** mã chỉ in ra nhật ký (Render: tab Logs, tìm "mã xác minh"). Người chơi thật sẽ không nhận được mã.
- **Chỉ để thử nghiệm:** đặt biến `SKIP_EMAIL_VERIFY=1` để bỏ bước xác minh. **Xóa biến này trước khi mở cho người chơi thật.**

## Tài khoản test & số điện thoại quốc tế (v34)
- Đăng ký chọn quốc gia (242 quốc gia/vùng lãnh thổ, mặc định Việt Nam +84); server lưu dạng số quốc tế (E.164).
- `TEST_ACCOUNTS=1` tạo sẵn tài khoản đã xác minh: `testplayer` / `123456` (đổi bằng `TEST_PASSWORD`).
  **Xoá biến này trước khi mở công khai.**

## Kết quả xúc xắc do server tạo (v45)
- App không còn tự tính kết quả. Server tạo bằng khoá bí mật (HMAC-SHA256) và chỉ công bố các ván **đã kết thúc** (`GET /api/results`).
- Đặt biến `RESULT_SECRET` (chuỗi ngẫu nhiên dài) trên Render để kết quả cũ không đổi khi server khởi động lại. Không đặt thì server tự sinh khoá và lưu trong cơ sở dữ liệu (mất khoá nếu mất dữ liệu).
- Vàng, rank vẫn tính trên máy người chơi cho đến khi chuyển phần chấm thắng thua sang server.

## Server chấm thắng thua (v46)
- Vàng, hạng, mưa vàng, nhiệm vụ, điểm danh, skin, code và mua sao của **tài khoản** do server tính và lưu (bảng `pstate`). App chỉ hiển thị, sửa trên máy không đổi được gì.
- Khách chưa đăng nhập vẫn chơi thử trên máy (10 vàng). Khi đăng ký, vàng chơi thử được mang theo tối đa `GUEST_MAX_CARRY` (mặc định 100); hạng/lãi không mang theo.
- Code thử (`test`, `nocode`, `newbie`) nằm trong `game.js`; đặt `DISABLE_TEST_CODES=1` để tắt hẳn trước khi phát hành.
- Đã bỏ `/api/score` và `/api/stars/mint`; thay bằng `/api/state`, `/api/pick`, `/api/daily`, `/api/mission`, `/api/skin`, `/api/code`, `/api/stars/buy`.
- Dữ liệu vẫn nằm trong file SQLite của Render: bản miễn phí sẽ mất khi khởi động lại cho tới khi nối Turso hoặc dùng ổ đĩa trả phí.

## Giữ dữ liệu khi Render khởi động lại (Turso)
Thêm 2 biến môi trường trên Render: `TURSO_URL` (dạng `libsql://...turso.io`) và `TURSO_TOKEN`.
- Khởi động: server tải dữ liệu từ Turso về. Nếu không kết nối được thì server dừng (không chạy bằng database rỗng).
- Đang chạy: cứ 10 giây, bảng nào đổi thì sao lưu lên Turso; khi Render tắt (SIGTERM) sẽ sao lưu nốt.
- Giới hạn: nếu server sập đột ngột, có thể mất tối đa ~10 giây dữ liệu gần nhất. Chỉ chạy 1 bản server (không chạy nhiều bản cùng lúc).
- Không đưa token vào GitHub.
