'use strict';
/**
 * Máy chủ Xúc Xắc Chơi Chung (giai đoạn 1): tài khoản + sao + code tặng sao.
 * Không cần cài thêm thư viện. Yêu cầu Node.js >= 22.5 (dùng node:sqlite có sẵn).
 *
 * Chạy:  node server.js     rồi mở http://localhost:3000
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

/* ===================== Cấu hình (đổi bằng biến môi trường) ===================== */
const PORT = Number(process.env.PORT || 3000);
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data.sqlite');
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || '';            // '' = chỉ cùng nguồn; hoặc 'https://trang-cua-ban.com'
const TRUST_PROXY = process.env.TRUST_PROXY === '1';            // =1 nếu chạy sau proxy/hosting (lấy IP từ X-Forwarded-For)
const GIFT_TTL_MS = Number(process.env.GIFT_TTL_HOURS || 24) * 3600 * 1000;   // code tặng hết hạn sau 24 giờ
const GIFT_MAX_PER_CODE = Number(process.env.GIFT_MAX_PER_CODE || 100);       // tối đa sao cho 1 code
const GIFT_DAILY_LIMIT = Number(process.env.GIFT_DAILY_LIMIT || 200);         // tối đa sao tặng / 24 giờ / người
const MINT_MAX_PER_CALL = 100;
const MINT_DAILY_LIMIT = Number(process.env.MINT_DAILY_LIMIT || 200);         // tối đa sao nhận thêm từ việc mua / 24 giờ
const SESSION_TTL_MS = 90 * 24 * 3600 * 1000;
const DAY_MS = 24 * 3600 * 1000;
const PUBLIC_URL = (process.env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/+$/, '');   // địa chỉ công khai, dùng trong link đặt lại mật khẩu
const CONTACT_EMAIL = process.env.CONTACT_EMAIL || 'contact@example.com';                      // email liên hệ hiện trong Điều khoản/Chính sách
const SITE_NAME = process.env.SITE_NAME || 'Xúc Xắc Chơi Chung';
// Gửi thư (cho tính năng quên mật khẩu): đặt MAIL_FROM + MỘT trong hai khoá API. Không đặt thì thư chỉ in ra nhật ký máy chủ.
const MAIL_FROM = process.env.MAIL_FROM || '';                 // địa chỉ người gửi đã xác minh với nhà cung cấp
const BREVO_API_KEY = process.env.BREVO_API_KEY || '';         // brevo.com (gói miễn phí, gửi được từ 1 email đã xác minh)
const RESEND_API_KEY = process.env.RESEND_API_KEY || '';       // resend.com (cần tên miền riêng đã xác minh)
const RESET_TTL_MS = 30 * 60 * 1000;                           // link đặt lại mật khẩu sống 30 phút
const MAX_FAILS = 5;                                           // sai mật khẩu 5 lần → khoá tạm
const LOCK_MS = 15 * 60 * 1000;                                // thời gian khoá tài khoản
const MIN_PASSWORD = 8;

/* ===================== Cơ sở dữ liệu ===================== */
const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    pass_salt TEXT NOT NULL,
    pass_hash TEXT NOT NULL,
    stars INTEGER NOT NULL DEFAULT 0 CHECK (stars >= 0),
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS gifts (
    code TEXT PRIMARY KEY,
    from_user INTEGER NOT NULL REFERENCES users(id),
    amount INTEGER NOT NULL CHECK (amount > 0),
    status TEXT NOT NULL DEFAULT 'open',          -- open | redeemed | cancelled | expired
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    redeemed_by INTEGER REFERENCES users(id),
    redeemed_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_gifts_from ON gifts(from_user, created_at);
CREATE TABLE IF NOT EXISTS star_log (            -- sổ cái: mọi thay đổi số sao đều ghi lại
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    delta INTEGER NOT NULL,
    kind TEXT NOT NULL,                           -- mint | gift_create | gift_redeem | gift_refund
    ref TEXT,
    at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_log_user ON star_log(user_id, kind, at);
CREATE TABLE IF NOT EXISTS reset_tokens (        -- link đặt lại mật khẩu: chỉ lưu bản băm, dùng 1 lần, hết hạn nhanh
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    expires_at INTEGER NOT NULL,
    created_at INTEGER NOT NULL
);
`);
// Nâng cấp bảng users cho CSDL cũ (thêm cột nếu chưa có)
{
    const cols = db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
    const add = (name, ddl) => { if (!cols.includes(name)) db.exec(`ALTER TABLE users ADD COLUMN ${name} ${ddl}`); };
    add('email', 'TEXT');
    add('marketing_ok', 'INTEGER NOT NULL DEFAULT 0');   // 1 = đồng ý nhận ưu đãi/gói tháng qua email
    add('terms_at', 'INTEGER');                          // thời điểm đồng ý Điều khoản
    add('fail_count', 'INTEGER NOT NULL DEFAULT 0');
    add('locked_until', 'INTEGER NOT NULL DEFAULT 0');
    db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email COLLATE NOCASE) WHERE email IS NOT NULL');
}

class HttpError extends Error {
    constructor(status, message) { super(message); this.status = status; }
}

// Chạy fn trong một giao dịch: hoặc làm xong hết, hoặc huỷ hết (không bao giờ nửa vời).
function tx(fn) {
    db.exec('BEGIN IMMEDIATE');
    try {
        const result = fn();
        db.exec('COMMIT');
        return result;
    } catch (e) {
        try { db.exec('ROLLBACK'); } catch (_) { /* bỏ qua */ }
        throw e;
    }
}

/* ===================== Hàm dùng chung ===================== */
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const toInt = (v) => (typeof v === 'number' || typeof v === 'string') && /^-?\d+$/.test(String(v).trim()) ? parseInt(String(v).trim(), 10) : NaN;

const buckets = new Map();
function rateLimit(key, max, windowMs) {
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || b.reset <= now) { b = { n: 0, reset: now + windowMs }; buckets.set(key, b); }
    b.n++;
    if (b.n > max) throw new HttpError(429, 'Bạn thao tác quá nhanh, vui lòng đợi một lát rồi thử lại.');
}
setInterval(() => {
    const now = Date.now();
    for (const [k, b] of buckets) if (b.reset <= now) buckets.delete(k);
}, 60 * 1000).unref();

function clientIp(req) {
    if (TRUST_PROXY) {
        const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
        if (xff) return xff;
    }
    return req.socket.remoteAddress || 'unknown';
}

function hashPassword(password, salt) {
    return crypto.scryptSync(password, salt, 64).toString('hex');
}

function checkPassword(password, username) {
    if (password.length < MIN_PASSWORD || password.length > 100) throw new HttpError(400, `Mật khẩu phải từ ${MIN_PASSWORD} đến 100 ký tự.`);
    if (username && password.toLowerCase() === String(username).toLowerCase()) throw new HttpError(400, 'Mật khẩu không được trùng tên đăng nhập.');
    if (/^(.)\1+$/.test(password) || /^(12345678|123456789|1234567890|password|matkhau12|qwertyui)$/i.test(password)) throw new HttpError(400, 'Mật khẩu quá dễ đoán, hãy chọn mật khẩu khác.');
}
function cleanEmail(raw) {
    const e = String(raw || '').trim().toLowerCase();
    if (e.length > 120 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) throw new HttpError(400, 'Email không hợp lệ.');
    return e;
}
function verifyPassword(row, password) {
    const hash = hashPassword(password, row.pass_salt);
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(row.pass_hash, 'hex'));
}
function setPassword(userId, password) {
    const salt = crypto.randomBytes(16).toString('hex');
    db.prepare('UPDATE users SET pass_salt = ?, pass_hash = ?, fail_count = 0, locked_until = 0 WHERE id = ?').run(salt, hashPassword(password, salt), userId);
}
const userInfo = (u) => ({ username: u.username, stars: u.stars, email: u.email || null, marketing: !!u.marketing_ok });

// Gửi thư. Lỗi gửi thư chỉ ghi nhật ký, không làm hỏng yêu cầu (và không để lộ email có tồn tại hay không).
async function sendMail(to, subject, text) {
    try {
        let res;
        if (BREVO_API_KEY && MAIL_FROM) {
            res = await fetch('https://api.brevo.com/v3/smtp/email', {
                method: 'POST',
                headers: { 'api-key': BREVO_API_KEY, 'content-type': 'application/json', accept: 'application/json' },
                body: JSON.stringify({ sender: { email: MAIL_FROM, name: SITE_NAME }, to: [{ email: to }], subject, textContent: text })
            });
        } else if (RESEND_API_KEY && MAIL_FROM) {
            res = await fetch('https://api.resend.com/emails', {
                method: 'POST',
                headers: { Authorization: `Bearer ${RESEND_API_KEY}`, 'content-type': 'application/json' },
                body: JSON.stringify({ from: `${SITE_NAME} <${MAIL_FROM}>`, to: [to], subject, text })
            });
        } else {
            console.log(`[MAIL chưa cấu hình, chỉ in ra nhật ký] tới ${to}\n  ${subject}\n  ${text.replace(/\n/g, '\n  ')}`);
            return;
        }
        if (!res.ok) console.error('[MAIL] gửi thất bại', res.status, (await res.text()).slice(0, 300));
    } catch (e) { console.error('[MAIL] lỗi', e.message); }
}

// Cộng/trừ sao cho một người và ghi sổ cái. Không cho số sao âm.
function addStars(userId, delta, kind, ref) {
    const r = db.prepare('UPDATE users SET stars = stars + ? WHERE id = ? AND stars + ? >= 0').run(delta, userId, delta);
    if (r.changes !== 1) throw new HttpError(400, 'Bạn không đủ sao.');
    db.prepare('INSERT INTO star_log (user_id, delta, kind, ref, at) VALUES (?, ?, ?, ?, ?)').run(userId, delta, kind, ref || null, Date.now());
}
const getStars = (userId) => db.prepare('SELECT stars FROM users WHERE id = ?').get(userId).stars;

// Code hết hạn → đánh dấu hết hạn và hoàn sao cho người tạo (gọi trong giao dịch).
function expireGifts(now) {
    const rows = db.prepare("SELECT code, from_user, amount FROM gifts WHERE status = 'open' AND expires_at <= ?").all(now);
    for (const g of rows) {
        const r = db.prepare("UPDATE gifts SET status = 'expired' WHERE code = ? AND status = 'open'").run(g.code);
        if (r.changes === 1) addStars(g.from_user, g.amount, 'gift_refund', g.code);
    }
}

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // bỏ I, O, 0, 1 cho dễ đọc
function randChunk(n) {
    let s = '';
    for (let i = 0; i < n; i++) s += ALPHABET[crypto.randomInt(ALPHABET.length)];
    return s;
}
const newCode = () => `SAO-${randChunk(4)}-${randChunk(4)}`;
function normalizeCode(input) {
    const c = String(input || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!/^SAO[A-Z0-9]{8}$/.test(c)) return null;
    return `SAO-${c.slice(3, 7)}-${c.slice(7)}`;
}

/* ===================== Xác thực ===================== */
function createSession(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions (token_hash, user_id, created_at) VALUES (?, ?, ?)').run(sha256(token), userId, Date.now());
    return token;
}

function authUser(req) {
    const h = String(req.headers.authorization || '');
    const m = /^Bearer ([a-f0-9]{64})$/.exec(h);
    if (!m) throw new HttpError(401, 'Bạn chưa đăng nhập.');
    const row = db.prepare(
        'SELECT u.id, u.username, u.stars, s.created_at AS sess_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?'
    ).get(sha256(m[1]));
    if (!row || Date.now() - row.sess_at > SESSION_TTL_MS) throw new HttpError(401, 'Phiên đăng nhập đã hết hạn, hãy đăng nhập lại.');
    return { id: row.id, username: row.username, token: m[1] };
}
const withAuth = (fn) => (ctx) => fn({ ...ctx, user: authUser(ctx.req) });

/* ===================== Các API ===================== */
const routes = {
    'POST /api/register': ({ body, ip }) => {
        rateLimit(`auth:${ip}`, 20, 10 * 60 * 1000);
        rateLimit(`reg:${ip}`, 10, 60 * 60 * 1000);
        const username = String(body.username || '').trim();
        const password = String(body.password || '');
        if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) throw new HttpError(400, 'Tên đăng nhập 3-20 ký tự: chữ không dấu, số hoặc dấu gạch dưới.');
        const email = cleanEmail(body.email);
        checkPassword(password, username);
        if (body.agree !== true) throw new HttpError(400, 'Bạn cần đồng ý Điều khoản và Chính sách bảo mật để tạo tài khoản.');
        const marketing = body.marketing === true ? 1 : 0;
        const salt = crypto.randomBytes(16).toString('hex');
        const now = Date.now();
        let userId;
        try {
            userId = Number(db.prepare('INSERT INTO users (username, email, marketing_ok, terms_at, pass_salt, pass_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
                .run(username, email, marketing, now, salt, hashPassword(password, salt), now).lastInsertRowid);
        } catch (e) {
            if (String(e.message).includes('users.email')) throw new HttpError(409, 'Email này đã được dùng cho tài khoản khác.');
            if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'Tên đăng nhập đã có người dùng.');
            throw e;
        }
        return { token: createSession(userId), username, stars: 0, email, marketing: !!marketing };
    },

    // Đăng nhập bằng tên đăng nhập hoặc email. Sai 5 lần → khoá 15 phút (kẻ đoán mật khẩu không đoán tiếp được).
    'POST /api/login': ({ body, ip }) => {
        rateLimit(`auth:${ip}`, 20, 10 * 60 * 1000);
        const login = String(body.username || '').trim();
        const password = String(body.password || '');
        if (!login || !password) throw new HttpError(400, 'Nhập tên đăng nhập (hoặc email) và mật khẩu.');
        const row = login.includes('@')
            ? db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE').get(login.toLowerCase())
            : db.prepare('SELECT * FROM users WHERE username = ?').get(login);
        const now = Date.now();
        if (row && row.locked_until > now) {
            throw new HttpError(429, `Tài khoản tạm khoá do nhập sai nhiều lần. Thử lại sau ${Math.ceil((row.locked_until - now) / 60000)} phút hoặc dùng "Quên mật khẩu".`);
        }
        const probe = row || { pass_salt: 'x'.repeat(32), pass_hash: '0'.repeat(128) };      // luôn băm để thời gian phản hồi như nhau
        const ok = verifyPassword(probe, password) && !!row;
        if (!ok) {
            if (row) {
                const fails = row.fail_count + 1;
                if (fails >= MAX_FAILS) db.prepare('UPDATE users SET fail_count = 0, locked_until = ? WHERE id = ?').run(now + LOCK_MS, row.id);
                else db.prepare('UPDATE users SET fail_count = ? WHERE id = ?').run(fails, row.id);
            }
            throw new HttpError(401, 'Sai tên đăng nhập hoặc mật khẩu.');
        }
        if (row.fail_count) db.prepare('UPDATE users SET fail_count = 0 WHERE id = ?').run(row.id);
        return Object.assign({ token: createSession(row.id) }, userInfo(row));
    },

    // Quên mật khẩu: luôn trả lời giống nhau dù email có tồn tại hay không (không cho dò email).
    'POST /api/forgot': ({ body, ip }) => {
        rateLimit(`forgot:${ip}`, 5, 15 * 60 * 1000);
        const email = cleanEmail(body.email);
        rateLimit(`forgot-mail:${email}`, 3, 60 * 60 * 1000);
        const u = db.prepare('SELECT id, username FROM users WHERE email = ? COLLATE NOCASE').get(email);
        if (u) {
            const token = crypto.randomBytes(32).toString('hex');
            tx(() => {
                db.prepare('DELETE FROM reset_tokens WHERE user_id = ?').run(u.id);
                db.prepare('INSERT INTO reset_tokens (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)').run(sha256(token), u.id, Date.now() + RESET_TTL_MS, Date.now());
            });
            void sendMail(email, `${SITE_NAME}: đặt lại mật khẩu`,
                `Xin chào ${u.username},\n\nBạn (hoặc ai đó) vừa yêu cầu đặt lại mật khẩu.\nBấm vào link dưới đây (có hiệu lực ${RESET_TTL_MS / 60000} phút, dùng 1 lần):\n\n${PUBLIC_URL}/#reset=${token}\n\nNếu không phải bạn, hãy bỏ qua thư này, mật khẩu của bạn vẫn an toàn.`);
        }
        return { sent: true };
    },

    'POST /api/reset': ({ body, ip }) => {
        rateLimit(`reset:${ip}`, 10, 15 * 60 * 1000);
        const token = String(body.token || '');
        const password = String(body.password || '');
        if (!/^[a-f0-9]{64}$/.test(token)) throw new HttpError(400, 'Link đặt lại mật khẩu không hợp lệ.');
        return tx(() => {
            const r = db.prepare('SELECT t.user_id, t.expires_at, u.username FROM reset_tokens t JOIN users u ON u.id = t.user_id WHERE t.token_hash = ?').get(sha256(token));
            if (!r || r.expires_at < Date.now()) throw new HttpError(400, 'Link đã hết hạn hoặc đã được dùng. Hãy yêu cầu link mới.');
            checkPassword(password, r.username);
            db.prepare('DELETE FROM reset_tokens WHERE user_id = ?').run(r.user_id);
            setPassword(r.user_id, password);
            db.prepare('DELETE FROM sessions WHERE user_id = ?').run(r.user_id);      // đăng xuất mọi thiết bị
            return {};
        });
    },

    'POST /api/logout': withAuth(({ user }) => {
        db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(user.token));
        return {};
    }),

    'GET /api/me': withAuth(({ user }) => {
        tx(() => expireGifts(Date.now()));
        return userInfo(db.prepare('SELECT username, stars, email, marketing_ok FROM users WHERE id = ?').get(user.id));
    }),

    // Cập nhật email khôi phục (phải nhập mật khẩu hiện tại) và/hoặc đồng ý nhận ưu đãi.
    'POST /api/profile': withAuth(({ user, body }) => {
        rateLimit(`profile:${user.id}`, 20, 10 * 60 * 1000);
        if (body.email !== undefined) {
            const row = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
            if (!verifyPassword(row, String(body.password || ''))) throw new HttpError(403, 'Mật khẩu hiện tại không đúng.');
            const email = cleanEmail(body.email);
            try { db.prepare('UPDATE users SET email = ? WHERE id = ?').run(email, user.id); }
            catch (e) { if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'Email này đã được dùng cho tài khoản khác.'); throw e; }
        }
        if (body.marketing !== undefined) db.prepare('UPDATE users SET marketing_ok = ? WHERE id = ?').run(body.marketing === true ? 1 : 0, user.id);
        return userInfo(db.prepare('SELECT username, stars, email, marketing_ok FROM users WHERE id = ?').get(user.id));
    }),

    // Đổi mật khẩu: các thiết bị khác bị đăng xuất.
    'POST /api/password': withAuth(({ user, body }) => {
        rateLimit(`pw:${user.id}`, 8, 15 * 60 * 1000);
        const row = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
        if (!verifyPassword(row, String(body.oldPassword || ''))) throw new HttpError(403, 'Mật khẩu hiện tại không đúng.');
        const pw = String(body.newPassword || '');
        checkPassword(pw, row.username);
        tx(() => {
            setPassword(user.id, pw);
            db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').run(user.id, sha256(user.token));
        });
        return {};
    }),

    // Xoá tài khoản: gỡ email và mật khẩu, đăng xuất mọi nơi. (Sổ cái sao giữ lại dưới tên ẩn danh.)
    'POST /api/account/delete': withAuth(({ user, body }) => {
        rateLimit(`del:${user.id}`, 5, 15 * 60 * 1000);
        const row = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
        if (!verifyPassword(row, String(body.password || ''))) throw new HttpError(403, 'Mật khẩu không đúng.');
        tx(() => {
            // huỷ các code còn mở của chính người này (hoàn sao) trước khi xoá
            for (const g of db.prepare("SELECT code, amount FROM gifts WHERE from_user = ? AND status = 'open'").all(user.id)) {
                if (db.prepare("UPDATE gifts SET status = 'cancelled' WHERE code = ? AND status = 'open'").run(g.code).changes === 1) addStars(user.id, g.amount, 'gift_refund', g.code);
            }
            const salt = crypto.randomBytes(16).toString('hex');
            db.prepare('UPDATE users SET username = ?, email = NULL, marketing_ok = 0, pass_salt = ?, pass_hash = ? WHERE id = ?')
                .run(`deleted_${user.id}`, salt, hashPassword(crypto.randomBytes(16).toString('hex'), salt), user.id);
            db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);
            db.prepare('DELETE FROM reset_tokens WHERE user_id = ?').run(user.id);
        });
        return {};
    }),

    // Nhận thêm sao khi người chơi dùng vàng mua sao (vàng hiện còn nằm trên máy người chơi → tạm tin máy khách, có hạn mức mỗi ngày).
    'POST /api/stars/mint': withAuth(({ user, body }) => {
        rateLimit(`mint:${user.id}`, 60, 60 * 1000);
        const qty = toInt(body.qty);
        if (!Number.isFinite(qty) || qty < 1 || qty > MINT_MAX_PER_CALL) throw new HttpError(400, `Số sao mỗi lần từ 1 đến ${MINT_MAX_PER_CALL}.`);
        return tx(() => {
            const used = db.prepare("SELECT COALESCE(SUM(delta), 0) AS s FROM star_log WHERE user_id = ? AND kind = 'mint' AND at > ?").get(user.id, Date.now() - DAY_MS).s;
            if (used + qty > MINT_DAILY_LIMIT) throw new HttpError(429, `Đã chạm giới hạn ${MINT_DAILY_LIMIT} sao mỗi 24 giờ.`);
            addStars(user.id, qty, 'mint', null);
            return { stars: getStars(user.id) };
        });
    }),

    // Tạo code tặng: trừ sao của người tạo ngay lúc tạo.
    'POST /api/gifts': withAuth(({ user, body }) => {
        rateLimit(`gift:${user.id}`, 20, 60 * 1000);
        const amount = toInt(body.amount);
        if (!Number.isFinite(amount) || amount < 1) throw new HttpError(400, 'Nhập số sao muốn tặng (ít nhất 1).');
        if (amount > GIFT_MAX_PER_CODE) throw new HttpError(400, `Mỗi code tặng tối đa ${GIFT_MAX_PER_CODE} sao.`);
        return tx(() => {
            const now = Date.now();
            expireGifts(now);
            const used = db.prepare("SELECT COALESCE(SUM(amount), 0) AS s FROM gifts WHERE from_user = ? AND created_at > ? AND status IN ('open', 'redeemed')").get(user.id, now - DAY_MS).s;
            if (used + amount > GIFT_DAILY_LIMIT) throw new HttpError(429, `Vượt giới hạn tặng ${GIFT_DAILY_LIMIT} sao mỗi 24 giờ (bạn đã tặng ${used}).`);
            let code;
            for (let i = 0; i < 5; i++) {
                const c = newCode();
                if (!db.prepare('SELECT 1 FROM gifts WHERE code = ?').get(c)) { code = c; break; }
            }
            if (!code) throw new HttpError(500, 'Không tạo được code, hãy thử lại.');
            addStars(user.id, -amount, 'gift_create', code);
            db.prepare('INSERT INTO gifts (code, from_user, amount, created_at, expires_at) VALUES (?, ?, ?, ?, ?)').run(code, user.id, amount, now, now + GIFT_TTL_MS);
            return { code, amount, expires_at: now + GIFT_TTL_MS, stars: getStars(user.id) };
        });
    }),

    // Danh sách code tôi đã tạo (kèm trạng thái).
    'GET /api/gifts': withAuth(({ user }) => tx(() => {
        expireGifts(Date.now());
        const gifts = db.prepare(`
            SELECT g.code, g.amount, g.status, g.created_at, g.expires_at, u.username AS redeemed_by
            FROM gifts g LEFT JOIN users u ON u.id = g.redeemed_by
            WHERE g.from_user = ? ORDER BY g.created_at DESC LIMIT 20`).all(user.id);
        return { gifts, stars: getStars(user.id) };
    })),

    // Nhận sao từ code: đánh dấu đã dùng + cộng sao trong cùng một giao dịch → không thể dùng 2 lần.
    'POST /api/gifts/redeem': withAuth(({ user, body }) => {
        rateLimit(`redeem:${user.id}`, 15, 60 * 1000);
        const code = normalizeCode(body.code);
        if (!code) throw new HttpError(400, 'Code không đúng định dạng (ví dụ SAO-ABCD-2345).');
        return tx(() => {
            const now = Date.now();
            expireGifts(now);
            const g = db.prepare('SELECT g.code, g.from_user, g.amount, g.status, u.username AS from_name FROM gifts g JOIN users u ON u.id = g.from_user WHERE g.code = ?').get(code);
            if (!g) throw new HttpError(404, 'Code không tồn tại.');
            if (g.status === 'expired') throw new HttpError(410, 'Code đã hết hạn.');
            if (g.status !== 'open') throw new HttpError(410, 'Code này đã được sử dụng hoặc đã bị huỷ.');
            if (g.from_user === user.id) throw new HttpError(400, 'Bạn không thể tự nhận code do chính mình tạo (hãy dùng nút Huỷ để lấy lại sao).');
            const r = db.prepare("UPDATE gifts SET status = 'redeemed', redeemed_by = ?, redeemed_at = ? WHERE code = ? AND status = 'open'").run(user.id, now, code);
            if (r.changes !== 1) throw new HttpError(410, 'Code này đã được sử dụng.');
            addStars(user.id, g.amount, 'gift_redeem', code);
            return { amount: g.amount, from: g.from_name, stars: getStars(user.id) };
        });
    }),

    // Người tạo huỷ code chưa ai nhận → hoàn sao.
    'POST /api/gifts/cancel': withAuth(({ user, body }) => {
        rateLimit(`cancel:${user.id}`, 20, 60 * 1000);
        const code = normalizeCode(body.code);
        if (!code) throw new HttpError(400, 'Code không đúng định dạng.');
        return tx(() => {
            expireGifts(Date.now());
            const g = db.prepare('SELECT code, from_user, amount, status FROM gifts WHERE code = ?').get(code);
            if (!g || g.from_user !== user.id) throw new HttpError(404, 'Không tìm thấy code của bạn.');
            if (g.status !== 'open') throw new HttpError(400, 'Code này không còn ở trạng thái chờ nhận.');
            const r = db.prepare("UPDATE gifts SET status = 'cancelled' WHERE code = ? AND status = 'open'").run(code);
            if (r.changes !== 1) throw new HttpError(400, 'Code này không còn ở trạng thái chờ nhận.');
            addStars(user.id, g.amount, 'gift_refund', code);
            return { stars: getStars(user.id) };
        });
    })
};

/* ===================== Máy chủ HTTP ===================== */
function readJson(req) {
    return new Promise((resolve, reject) => {
        let size = 0;
        const chunks = [];
        req.on('data', (c) => {
            size += c.length;
            if (size > 8 * 1024) { reject(new HttpError(413, 'Dữ liệu gửi lên quá lớn.')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', () => {
            if (!chunks.length) return resolve({});
            try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')) || {}); }
            catch (_) { reject(new HttpError(400, 'Dữ liệu không phải JSON hợp lệ.')); }
        });
        req.on('error', reject);
    });
}

function send(res, status, body, headers) {
    const sec = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer' };
    if (TRUST_PROXY) sec['Strict-Transport-Security'] = 'max-age=31536000';
    res.writeHead(status, Object.assign(sec, headers));
    res.end(body);
}
const sendJson = (res, status, obj) => send(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8' });

// Thư mục chứa trang web: ./public nếu có, không thì cùng thư mục với server.js (bản phẳng để tải lên từ điện thoại)
const PUB_DIR = fs.existsSync(path.join(__dirname, 'public')) ? path.join(__dirname, 'public') : __dirname;
const INDEX_FILE = path.join(PUB_DIR, 'index.html');

const server = http.createServer(async (req, res) => {
    try {
        if (ALLOW_ORIGIN) {
            res.setHeader('Access-Control-Allow-Origin', ALLOW_ORIGIN);
            res.setHeader('Vary', 'Origin');
            res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        }
        if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

        let url;
        try { url = new URL(String(req.url).replace(/^\/{2,}/, '/'), 'http://localhost'); }
        catch (_) { throw new HttpError(400, 'Đường dẫn không hợp lệ.'); }
        if (url.pathname.startsWith('/api/')) {
            const handler = routes[`${req.method} ${url.pathname}`];
            if (!handler) throw new HttpError(404, 'Không tìm thấy.');
            const body = req.method === 'POST' ? await readJson(req) : {};
            const result = await handler({ req, body, ip: clientIp(req) });
            sendJson(res, 200, Object.assign({ ok: true }, result));
            return;
        }
        if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
            send(res, 200, fs.readFileSync(INDEX_FILE), { 'Content-Type': 'text/html; charset=utf-8' });
            return;
        }
        if (req.method === 'GET' && (url.pathname === '/terms' || url.pathname === '/privacy')) {
            const page = fs.readFileSync(path.join(PUB_DIR, url.pathname.slice(1) + '.html'), 'utf8')
                .replaceAll('{{CONTACT_EMAIL}}', CONTACT_EMAIL).replaceAll('{{SITE_NAME}}', SITE_NAME);
            send(res, 200, page, { 'Content-Type': 'text/html; charset=utf-8' });
            return;
        }
        if (req.method === 'GET' && url.pathname === '/healthz') { send(res, 200, 'ok', { 'Content-Type': 'text/plain' }); return; }
        throw new HttpError(404, 'Không tìm thấy.');
    } catch (e) {
        const status = e.status || 500;
        if (status === 500) console.error(e);
        sendJson(res, status, { ok: false, error: status === 500 ? 'Lỗi máy chủ.' : e.message });
    }
});

if (require.main === module) {
    // dọn phiên đăng nhập quá hạn mỗi giờ
    setInterval(() => {
        try {
            db.prepare('DELETE FROM sessions WHERE created_at < ?').run(Date.now() - SESSION_TTL_MS);
            db.prepare('DELETE FROM reset_tokens WHERE expires_at < ?').run(Date.now());
        } catch (_) { /* bỏ qua */ }
    }, 3600 * 1000).unref();
    server.listen(PORT, () => console.log(`Xúc Xắc Chơi Chung chạy tại http://localhost:${PORT}`));
}

module.exports = { server, db };
