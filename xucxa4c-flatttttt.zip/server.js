'use strict';
/**
 * Máy chủ Game Vui Quà Khủng (giai đoạn 1): tài khoản + sao + code tặng sao.
 * Không cần cài thêm thư viện. Yêu cầu Node.js >= 22.5 (dùng node:sqlite có sẵn).
 *
 * Chạy:  node server.js     rồi mở http://localhost:3000
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const turso = require('./turso');

/* ===================== Cấu hình (đổi bằng biến môi trường) ===================== */
const PORT = Number(process.env.PORT || 3000);
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data.sqlite');
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || '';            // '' = chỉ cùng nguồn; hoặc 'https://trang-cua-ban.com'
const TRUST_PROXY = process.env.TRUST_PROXY === '1';            // =1 nếu chạy sau proxy/hosting (lấy IP từ X-Forwarded-For)
const GIFT_TTL_MS = Number(process.env.GIFT_TTL_HOURS || 24) * 3600 * 1000;   // code tặng hết hạn sau 24 giờ
const GIFT_MAX_PER_CODE = Number(process.env.GIFT_MAX_PER_CODE || 10);        // tối đa sao cho 1 code
const GIFT_DAILY_LIMIT = Number(process.env.GIFT_DAILY_LIMIT || 10);          // tối đa sao tặng mỗi cửa sổ / người
const GIFT_WINDOW_MS = Number(process.env.GIFT_WINDOW_HOURS || 2) * 3600 * 1000; // cửa sổ 2 giờ
const MINT_MAX_PER_CALL = 100;
const MINT_DAILY_LIMIT = Number(process.env.MINT_DAILY_LIMIT || 200);         // tối đa sao nhận thêm từ việc mua / 24 giờ
const SESSION_TTL_MS = 90 * 24 * 3600 * 1000;
const DAY_MS = 24 * 3600 * 1000;
const PUBLIC_URL = (process.env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/+$/, '');   // địa chỉ công khai, dùng trong link đặt lại mật khẩu
const CONTACT_EMAIL = process.env.CONTACT_EMAIL || 'contact@example.com';                      // email liên hệ hiện trong Điều khoản/Chính sách
const SITE_NAME = process.env.SITE_NAME || 'Game Vui Quà Khủng';
// Gửi thư (cho tính năng quên mật khẩu): đặt MAIL_FROM + MỘT trong hai khoá API. Không đặt thì thư chỉ in ra nhật ký máy chủ.
const SKIP_EMAIL_VERIFY = process.env.SKIP_EMAIL_VERIFY === '1';   // CHỈ để thử nghiệm: bỏ bước xác minh email
const VERIFY_TTL_MS = 15 * 60 * 1000;
const MAIL_FROM = process.env.MAIL_FROM || '';                 // địa chỉ người gửi đã xác minh với nhà cung cấp
const BREVO_API_KEY = process.env.BREVO_API_KEY || '';         // brevo.com (gói miễn phí, gửi được từ 1 email đã xác minh)
const RESEND_API_KEY = process.env.RESEND_API_KEY || '';       // resend.com (cần tên miền riêng đã xác minh)
const RESET_TTL_MS = 30 * 60 * 1000;                           // link đặt lại mật khẩu sống 30 phút
const MAX_FAILS = 5;                                           // sai mật khẩu 5 lần → khoá tạm
const LOCK_MS = 15 * 60 * 1000;                                // thời gian khoá tài khoản
const MIN_PASSWORD = 8;

/* ===================== Cơ sở dữ liệu ===================== */
const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    pass_salt TEXT NOT NULL,
    pass_hash TEXT NOT NULL,
    stars INTEGER NOT NULL DEFAULT 0 CHECK (stars >= 0),
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS gifts (
    code TEXT PRIMARY KEY,
    from_user INTEGER NOT NULL REFERENCES users(id),
    amount INTEGER NOT NULL CHECK (amount > 0),
    status TEXT NOT NULL DEFAULT 'open',          -- open | redeemed | cancelled | expired
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    redeemed_by INTEGER REFERENCES users(id),
    redeemed_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_gifts_from ON gifts(from_user, created_at);
CREATE TABLE IF NOT EXISTS star_log (            -- sổ cái: mọi thay đổi số sao đều ghi lại
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    delta INTEGER NOT NULL,
    kind TEXT NOT NULL,                           -- mint | gift_create | gift_redeem | gift_refund
    ref TEXT,
    at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_log_user ON star_log(user_id, kind, at);
CREATE TABLE IF NOT EXISTS lb_week (               -- bảng xếp hạng tuần: số ván thắng (do máy người chơi báo, có giới hạn tốc độ)
    week TEXT NOT NULL,                           -- ngày Thứ Hai của tuần (giờ VN)
    user_id INTEGER NOT NULL REFERENCES users(id),
    wins INTEGER NOT NULL DEFAULT 0,
    day TEXT NOT NULL DEFAULT '',
    day_wins INTEGER NOT NULL DEFAULT 0,
    updated_at INTEGER NOT NULL,
    PRIMARY KEY (week, user_id)
);
CREATE INDEX IF NOT EXISTS idx_lb_week ON lb_week(week, wins DESC);
CREATE TABLE IF NOT EXISTS verify_codes (         -- mã xác minh email (6 số): chỉ lưu bản băm, hết hạn 15 phút, tối đa 5 lần thử
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    code_hash TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    sent_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reset_tokens (        -- link đặt lại mật khẩu: chỉ lưu bản băm, dùng 1 lần, hết hạn nhanh
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    expires_at INTEGER NOT NULL,
    created_at INTEGER NOT NULL
);
`);
// Nâng cấp bảng users cho CSDL cũ (thêm cột nếu chưa có)
{
    const cols = db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
    const add = (name, ddl) => { if (!cols.includes(name)) db.exec(`ALTER TABLE users ADD COLUMN ${name} ${ddl}`); };
    add('email', 'TEXT');
    add('marketing_ok', 'INTEGER NOT NULL DEFAULT 0');   // 1 = đồng ý nhận ưu đãi/gói tháng qua email
    add('terms_at', 'INTEGER');                          // thời điểm đồng ý Điều khoản
    if (!cols.includes('email_verified')) {                      // tài khoản có từ trước coi như đã xác minh
        db.exec('ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0');
        db.exec('UPDATE users SET email_verified = 1');
    }
    add('phone', 'TEXT');                                // số điện thoại (chưa xác minh OTP), tối đa PHONE_MAX_ACCOUNTS tài khoản/số
    add('phone_verified', 'INTEGER NOT NULL DEFAULT 0'); // 1 = đã xác minh OTP (cần nhà cung cấp SMS, chưa bật)
    add('fail_count', 'INTEGER NOT NULL DEFAULT 0');
    add('locked_until', 'INTEGER NOT NULL DEFAULT 0');
    db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email COLLATE NOCASE) WHERE email IS NOT NULL');
}

// Tuần/ngày tính theo giờ Việt Nam (UTC+7); tuần bắt đầu Thứ Hai
const vnDay = (ms = Date.now()) => new Date(ms + 7 * 3600 * 1000);
const vnDayKey = (ms) => vnDay(ms).toISOString().slice(0, 10);
const vnWeekKey = (ms) => { const d = vnDay(ms); return new Date(d.getTime() - ((d.getUTCDay() + 6) % 7) * 86400000).toISOString().slice(0, 10); };

class HttpError extends Error {
    constructor(status, message) { super(message); this.status = status; }
}

// Chạy fn trong một giao dịch: hoặc làm xong hết, hoặc huỷ hết (không bao giờ nửa vời).
function tx(fn) {
    db.exec('BEGIN IMMEDIATE');
    try {
        const result = fn();
        db.exec('COMMIT');
        return result;
    } catch (e) {
        try { db.exec('ROLLBACK'); } catch (_) { /* bỏ qua */ }
        throw e;
    }
}

const game = require('./game');
db.exec(`CREATE TABLE IF NOT EXISTS pstate (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    json TEXT NOT NULL,
    updated_at INTEGER NOT NULL
)`);
const REG_BONUS = 30, GUEST_MAX_CARRY = Number(process.env.GUEST_MAX_CARRY || 100);
function loadP(userId) {
    const r = db.prepare('SELECT json FROM pstate WHERE user_id = ?').get(userId);
    if (r) return JSON.parse(r.json);
    const p = game.newState(REG_BONUS);
    saveP(userId, p);
    return p;
}
function saveP(userId, p) {
    db.prepare('INSERT INTO pstate (user_id, json, updated_at) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET json = excluded.json, updated_at = excluded.updated_at')
        .run(userId, JSON.stringify(p), Date.now());
}

/* ===================== Kết quả xúc xắc do server tạo ===================== */
// Khoá bí mật: đặt RESULT_SECRET trên Render để kết quả cũ không đổi khi server khởi động lại.
// Không đặt thì server tự sinh một khoá ngẫu nhiên và lưu trong cơ sở dữ liệu.
db.exec('CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT NOT NULL)');
if (turso.enabled) {   // khôi phục dữ liệu từ Turso trước khi dùng (nếu lỗi → dừng, tránh ghi đè dữ liệu cũ bằng DB rỗng)
    const n = turso.importInto(db, turso.restoreSync());
    console.log('Turso: đã khôi phục ' + n + ' dòng');
}
const RESULT_SECRET = process.env.RESULT_SECRET || (() => {
    const row = db.prepare("SELECT v FROM settings WHERE k = 'result_secret'").get();
    if (row) return row.v;
    const v = crypto.randomBytes(32).toString('hex');
    db.prepare("INSERT OR REPLACE INTO settings (k, v) VALUES ('result_secret', ?)").run(v);
    return v;
})();
const ROUND_MS = 60 * 1000, RED_MAX = 10, SEG_SUPER = 120;
// Bộ số ngẫu nhiên giả theo HMAC-SHA256: không đoán được ván sau dù biết hết các ván trước
function prf(label) {
    let ctr = 0;
    return () => crypto.createHmac('sha256', RESULT_SECRET).update(`${label}|${ctr++}`).digest().readUIntBE(0, 6) / 281474976710656;
}
const colorOfSum = (sum) => (sum <= RED_MAX ? 'RED' : 'GREEN');
const segCache = new Map();
function segmentsFor(room, sb) {
    const key = `${room}|${sb}`;
    if (segCache.has(key)) return segCache.get(key);
    const rnd = prf(`S|${room}|${sb}`);
    let mode = rnd() < 0.5 ? 'order' : 'chaos';
    const segs = [];
    for (let pos = 0; pos < SEG_SUPER;) {
        const len = mode === 'order' ? 5 + Math.floor(rnd() * 5) : 6 + Math.floor(rnd() * 6);
        const seg = { start: pos, len, mode };
        if (mode === 'order') { seg.run = 1 + Math.floor(rnd() * 4); seg.c0 = rnd() < 0.5 ? 0 : 1; }
        segs.push(seg);
        pos += len;
        mode = mode === 'order' ? 'chaos' : 'order';
    }
    if (segCache.size > 2000) segCache.clear();
    segCache.set(key, segs);
    return segs;
}
// Nhịp "trật tự ⇄ hỗn loạn", mỗi màu đúng 50% về lâu dài
function targetColorOf(room, k) {
    const sb = Math.floor(k / SEG_SUPER), off = k - sb * SEG_SUPER;
    const seg = segmentsFor(room, sb).find((x) => off >= x.start && off < x.start + x.len);
    let bit;
    if (seg.mode === 'order') bit = (seg.c0 + Math.floor((off - seg.start) / seg.run)) & 1;
    else bit = prf(`C|${room}|${k}`)() < 0.5 ? 0 : 1;
    return bit === 0 ? 'RED' : 'GREEN';
}
function diceFor(room, k) {
    const rnd = prf(`D|${room}|${k}`);
    const target = targetColorOf(room, k);
    let d;
    for (let i = 0; i < 200; i++) {                      // lấy 3 xúc xắc cho tới khi ra đúng màu đã định
        d = [0, 1, 2].map(() => Math.floor(rnd() * 6) + 1);
        if (colorOfSum(d[0] + d[1] + d[2]) === target) break;
    }
    return d;
}

/* ===================== Hàm dùng chung ===================== */
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const toInt = (v) => (typeof v === 'number' || typeof v === 'string') && /^-?\d+$/.test(String(v).trim()) ? parseInt(String(v).trim(), 10) : NaN;

const buckets = new Map();
function rateLimit(key, max, windowMs) {
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || b.reset <= now) { b = { n: 0, reset: now + windowMs }; buckets.set(key, b); }
    b.n++;
    if (b.n > max) throw new HttpError(429, 'Bạn thao tác quá nhanh, vui lòng đợi một lát rồi thử lại.');
}
setInterval(() => {
    const now = Date.now();
    for (const [k, b] of buckets) if (b.reset <= now) buckets.delete(k);
}, 60 * 1000).unref();

function clientIp(req) {
    if (TRUST_PROXY) {
        const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
        if (xff) return xff;
    }
    return req.socket.remoteAddress || 'unknown';
}

function hashPassword(password, salt) {
    return crypto.scryptSync(password, salt, 64).toString('hex');
}

function checkPassword(password, username) {
    if (password.length < MIN_PASSWORD || password.length > 100) throw new HttpError(400, `Mật khẩu phải từ ${MIN_PASSWORD} đến 100 ký tự.`);
    if (username && password.toLowerCase() === String(username).toLowerCase()) throw new HttpError(400, 'Mật khẩu không được trùng tên đăng nhập.');
    if (/^(.)\1+$/.test(password) || /^(12345678|123456789|1234567890|password|matkhau12|qwertyui)$/i.test(password)) throw new HttpError(400, 'Mật khẩu quá dễ đoán, hãy chọn mật khẩu khác.');
}
function cleanEmail(raw) {
    const e = String(raw || '').trim().toLowerCase();
    if (e.length > 120 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) throw new HttpError(400, 'Email không hợp lệ.');
    return e;
}
function verifyPassword(row, password) {
    const hash = hashPassword(password, row.pass_salt);
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(row.pass_hash, 'hex'));
}
function setPassword(userId, password) {
    const salt = crypto.randomBytes(16).toString('hex');
    db.prepare('UPDATE users SET pass_salt = ?, pass_hash = ?, fail_count = 0, locked_until = 0 WHERE id = ?').run(salt, hashPassword(password, salt), userId);
}
const userInfo = (u) => ({ username: u.username, stars: u.stars, email: u.email || null, marketing: !!u.marketing_ok });

// Gửi thư. Lỗi gửi thư chỉ ghi nhật ký, không làm hỏng yêu cầu (và không để lộ email có tồn tại hay không).
async function sendMail(to, subject, text) {
    try {
        let res;
        if (BREVO_API_KEY && MAIL_FROM) {
            res = await fetch('https://api.brevo.com/v3/smtp/email', {
                method: 'POST',
                headers: { 'api-key': BREVO_API_KEY, 'content-type': 'application/json', accept: 'application/json' },
                body: JSON.stringify({ sender: { email: MAIL_FROM, name: SITE_NAME }, to: [{ email: to }], subject, textContent: text })
            });
        } else if (RESEND_API_KEY && MAIL_FROM) {
            res = await fetch('https://api.resend.com/emails', {
                method: 'POST',
                headers: { Authorization: `Bearer ${RESEND_API_KEY}`, 'content-type': 'application/json' },
                body: JSON.stringify({ from: `${SITE_NAME} <${MAIL_FROM}>`, to: [to], subject, text })
            });
        } else {
            console.log(`[MAIL chưa cấu hình, chỉ in ra nhật ký] tới ${to}\n  ${subject}\n  ${text.replace(/\n/g, '\n  ')}`);
            return;
        }
        if (!res.ok) console.error('[MAIL] gửi thất bại', res.status, (await res.text()).slice(0, 300));
    } catch (e) { console.error('[MAIL] lỗi', e.message); }
}

// Cộng/trừ sao cho một người và ghi sổ cái. Không cho số sao âm.
function addStars(userId, delta, kind, ref) {
    const r = db.prepare('UPDATE users SET stars = stars + ? WHERE id = ? AND stars + ? >= 0').run(delta, userId, delta);
    if (r.changes !== 1) throw new HttpError(400, 'Bạn không đủ sao.');
    db.prepare('INSERT INTO star_log (user_id, delta, kind, ref, at) VALUES (?, ?, ?, ?, ?)').run(userId, delta, kind, ref || null, Date.now());
}
const getStars = (userId) => db.prepare('SELECT stars FROM users WHERE id = ?').get(userId).stars;

// Code hết hạn → đánh dấu hết hạn và hoàn sao cho người tạo (gọi trong giao dịch).
function expireGifts(now) {
    const rows = db.prepare("SELECT code, from_user, amount FROM gifts WHERE status = 'open' AND expires_at <= ?").all(now);
    for (const g of rows) {
        const r = db.prepare("UPDATE gifts SET status = 'expired' WHERE code = ? AND status = 'open'").run(g.code);
        if (r.changes === 1) addStars(g.from_user, g.amount, 'gift_refund', g.code);
    }
}

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // bỏ I, O, 0, 1 cho dễ đọc
function randChunk(n) {
    let s = '';
    for (let i = 0; i < n; i++) s += ALPHABET[crypto.randomInt(ALPHABET.length)];
    return s;
}
const newCode = () => `SAO-${randChunk(4)}-${randChunk(4)}`;
function normalizeCode(input) {
    const c = String(input || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!/^SAO[A-Z0-9]{8}$/.test(c)) return null;
    return `SAO-${c.slice(3, 7)}-${c.slice(7)}`;
}

/* ===================== Xác thực ===================== */
// Tạo + gửi mã xác minh 6 số tới email của user. Giới hạn: 1 mã/60 giây/tài khoản.
function issueVerifyCode(user, { force = false } = {}) {
    const prev = db.prepare('SELECT sent_at FROM verify_codes WHERE user_id = ?').get(user.id);
    if (!force && prev && Date.now() - prev.sent_at < 60 * 1000) throw new HttpError(429, 'Vừa gửi mã xong, hãy đợi khoảng 1 phút rồi bấm gửi lại.');
    const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    db.prepare('INSERT OR REPLACE INTO verify_codes (user_id, code_hash, expires_at, attempts, sent_at) VALUES (?, ?, ?, 0, ?)')
        .run(user.id, sha256(`${user.id}:${code}`), Date.now() + VERIFY_TTL_MS, Date.now());
    void sendMail(user.email, `${SITE_NAME}: mã xác minh ${code}`,
        `Xin chào ${user.username},\n\nMã xác minh email của bạn là: ${code}\n(Có hiệu lực ${VERIFY_TTL_MS / 60000} phút. Không chia sẻ mã này cho ai.)\n\nNếu bạn không đăng ký, hãy bỏ qua thư này.`);
}
const maskEmail = (e) => String(e).replace(/^(.).*(@.*)$/, (_, a, b) => a + '***' + b);

function createSession(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions (token_hash, user_id, created_at) VALUES (?, ?, ?)').run(sha256(token), userId, Date.now());
    return token;
}

function authUser(req) {
    const h = String(req.headers.authorization || '');
    const m = /^Bearer ([a-f0-9]{64})$/.exec(h);
    if (!m) throw new HttpError(401, 'Bạn chưa đăng nhập.');
    const row = db.prepare(
        'SELECT u.id, u.username, u.stars, s.created_at AS sess_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?'
    ).get(sha256(m[1]));
    if (!row || Date.now() - row.sess_at > SESSION_TTL_MS) throw new HttpError(401, 'Phiên đăng nhập đã hết hạn, hãy đăng nhập lại.');
    return { id: row.id, username: row.username, token: m[1] };
}
// Chạy một thao tác game trong một giao dịch: chấm các ván đã kết thúc → thực hiện thao tác → lưu → trả trạng thái mới
const isFairUser = (user) => process.env.TEST_ACCOUNTS === '1' && user.username === 'testplayer';   // tài khoản thử: vòng quay luôn 50/50
function gameCall(user, req, action) {
    rateLimit(`game:${user.id}`, 240, 60 * 1000);
    const u = new URL(String(req.url).replace(/^\/{2,}/, '/'), 'http://localhost');
    const room = String(u.searchParams.get('room') || 'chung').trim().slice(0, 24) || 'chung';
    const now = Date.now(), cur = Math.floor(now / game.ROUND_MS);
    const out = tx(() => {
        const p = loadP(user.id);
        const wk = vnWeekKey(), dk = vnDayKey();
        const onWin = () => {
            const r = db.prepare('SELECT wins, day, day_wins FROM lb_week WHERE week = ? AND user_id = ?').get(wk, user.id);
            const dayWins = r && r.day === dk ? r.day_wins : 0;
            if (dayWins >= 800) return;                                         // trần chống cày bảng xếp hạng
            if (!r) db.prepare('INSERT INTO lb_week (week, user_id, wins, day, day_wins, updated_at) VALUES (?, ?, 1, ?, 1, ?)').run(wk, user.id, dk, now);
            else db.prepare('UPDATE lb_week SET wins = wins + 1, day = ?, day_wins = ?, updated_at = ? WHERE week = ? AND user_id = ?').run(dk, dayWins + 1, now, wk, user.id);
        };
        const s = game.settle(p, cur, (rm, k) => diceFor(rm, k), now, onWin);
        let extra = {};
        if (action) {
            try { extra = action(p, now, cur, room) || {}; }
            catch (e) {
                if (e instanceof game.GameError) {                              // lỗi do người chơi: vẫn lưu kết quả chấm ván, trả lỗi ra ngoài giao dịch
                    saveP(user.id, p);
                    return { err: e.message, extra: { state: game.view(p, room), outcomes: s.outcomes, events: s.events, stars: getStars(user.id), now, cur } };
                }
                throw e;
            }
        }
        game.ensure(p, now);
        const events = s.events.concat(extra.events || []);
        saveP(user.id, p);
        return { state: game.view(p, room), outcomes: s.outcomes, events, delta: extra.delta, wheel: extra.wheel, wheelGreen: game.wheelGreen(p, isFairUser(user)), wheelGs: (p.wheel && p.wheel.gs) || 0, stars: getStars(user.id), now, cur };
    });
    if (out.err) throw Object.assign(new HttpError(400, out.err), { extra: out.extra });
    return out;
}
const withAuth = (fn) => (ctx) => fn({ ...ctx, user: authUser(ctx.req) });

/* ===================== Các API ===================== */
const routes = {
    'POST /api/register': ({ body, ip }) => {
        rateLimit(`auth:${ip}`, 20, 10 * 60 * 1000);
        rateLimit(`reg:${ip}`, 10, 60 * 60 * 1000);
        const username = String(body.username || '').trim();
        const password = String(body.password || '');
        if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) throw new HttpError(400, 'Tên đăng nhập 3-20 ký tự: chữ không dấu, số hoặc dấu gạch dưới.');
        const email = cleanEmail(body.email);
        checkPassword(password, username);
        if (body.agree !== true) throw new HttpError(400, 'Bạn cần đồng ý Điều khoản và Chính sách bảo mật để tạo tài khoản.');
        const marketing = body.marketing === true ? 1 : 0;
        // Số điện thoại: bỏ khoảng trắng/dấu; 0xxxxxxxxx (VN) quy về 84xxxxxxxxx
        // "+<mã nước><số>" (quốc tế). Số không có dấu + thì hiểu là số Việt Nam: 0xxxxxxxxx → 84xxxxxxxxx
        const rawPhone = String(body.phone || '').trim();
        let phone = rawPhone.replace(/[^\d]/g, '');
        if (!rawPhone.startsWith('+') && phone.startsWith('0')) phone = '84' + phone.slice(1);
        if (phone.length < 8 || phone.length > 15 || /^0/.test(phone)) throw new HttpError(400, 'Số điện thoại không hợp lệ.');
        const PHONE_MAX = Number(process.env.PHONE_MAX_ACCOUNTS || 3);
        const salt = crypto.randomBytes(16).toString('hex');
        const now = Date.now();
        // tài khoản CHƯA xác minh trùng tên/email thì cho đăng ký đè (người thật chưa kịp xác minh), tránh bị giữ chỗ
        db.prepare('DELETE FROM users WHERE email_verified = 0 AND (username = ? OR email = ? COLLATE NOCASE)').run(username, email);
        if (db.prepare('SELECT COUNT(*) AS n FROM users WHERE phone = ?').get(phone).n >= PHONE_MAX) {
            throw new HttpError(409, `Số điện thoại này đã dùng cho ${PHONE_MAX} tài khoản (tối đa).`);
        }
        let userId;
        try {
            userId = Number(db.prepare('INSERT INTO users (username, email, phone, marketing_ok, terms_at, pass_salt, pass_hash, created_at, email_verified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
                .run(username, email, phone, marketing, now, salt, hashPassword(password, salt), now, SKIP_EMAIL_VERIFY ? 1 : 0).lastInsertRowid);
        } catch (e) {
            if (String(e.message).includes('users.email')) throw new HttpError(409, 'Email này đã được dùng cho tài khoản khác.');
            if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'Tên đăng nhập đã có người dùng.');
            throw e;
        }
        // vàng chơi thử của khách mang theo (tối đa GUEST_MAX_CARRY); hết vàng thì tặng REG_BONUS
        const carry = Math.floor(Number(body.carryGold));
        saveP(userId, game.newState(Number.isFinite(carry) && carry >= 1 ? Math.min(carry, GUEST_MAX_CARRY) : REG_BONUS));
        if (!SKIP_EMAIL_VERIFY) {                                   // chưa cấp phiên: phải nhập mã gửi tới email trước
            issueVerifyCode({ id: userId, username, email }, { force: true });
            return { needVerify: true, username, email: maskEmail(email) };
        }
        return { token: createSession(userId), username, stars: 0, email, marketing: !!marketing };
    },

    // Đăng nhập bằng tên đăng nhập hoặc email. Sai 5 lần → khoá 15 phút (kẻ đoán mật khẩu không đoán tiếp được).
    'POST /api/login': ({ body, ip }) => {
        rateLimit(`auth:${ip}`, 20, 10 * 60 * 1000);
        const login = String(body.username || '').trim();
        const password = String(body.password || '');
        if (!login || !password) throw new HttpError(400, 'Nhập tên đăng nhập (hoặc email) và mật khẩu.');
        const row = login.includes('@')
            ? db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE').get(login.toLowerCase())
            : db.prepare('SELECT * FROM users WHERE username = ?').get(login);
        const now = Date.now();
        if (row && row.locked_until > now) {
            throw new HttpError(429, `Tài khoản tạm khoá do nhập sai nhiều lần. Thử lại sau ${Math.ceil((row.locked_until - now) / 60000)} phút hoặc dùng "Quên mật khẩu".`);
        }
        const probe = row || { pass_salt: 'x'.repeat(32), pass_hash: '0'.repeat(128) };      // luôn băm để thời gian phản hồi như nhau
        const ok = verifyPassword(probe, password) && !!row;
        if (!ok) {
            if (row) {
                const fails = row.fail_count + 1;
                if (fails >= MAX_FAILS) db.prepare('UPDATE users SET fail_count = 0, locked_until = ? WHERE id = ?').run(now + LOCK_MS, row.id);
                else db.prepare('UPDATE users SET fail_count = ? WHERE id = ?').run(fails, row.id);
            }
            throw new HttpError(401, 'Sai tên đăng nhập hoặc mật khẩu.');
        }
        if (row.fail_count) db.prepare('UPDATE users SET fail_count = 0 WHERE id = ?').run(row.id);
        if (!row.email_verified) {
            try { issueVerifyCode(row); } catch (_) { /* vừa gửi, bỏ qua */ }
            const e = new HttpError(403, 'Tài khoản chưa xác minh email. Hãy nhập mã 6 số vừa gửi tới email của bạn.');
            e.extra = { needVerify: true, username: row.username, email: maskEmail(row.email) };
            throw e;
        }
        return Object.assign({ token: createSession(row.id) }, userInfo(row));
    },

    // Xác nhận mã 6 số gửi tới email → mở tài khoản và cấp phiên đăng nhập
    'POST /api/verify': ({ body, ip }) => {
        rateLimit(`verify:${ip}`, 20, 15 * 60 * 1000);
        const username = String(body.username || '').trim();
        const code = String(body.code || '').replace(/\D/g, '');
        if (code.length !== 6) throw new HttpError(400, 'Nhập đủ mã 6 số.');
        // lưu ý: lỗi ném BÊN TRONG tx sẽ hoàn tác cả lần đếm sai, nên trả về lỗi rồi ném bên ngoài
        const res = tx(() => {
            const u = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
            const v = u && db.prepare('SELECT * FROM verify_codes WHERE user_id = ?').get(u.id);
            if (!u || !v || v.expires_at < Date.now()) return { err: [400, 'Mã đã hết hạn hoặc không đúng. Bấm "Gửi lại mã".'] };
            if (v.attempts >= 5) return { err: [429, 'Nhập sai quá nhiều lần. Bấm "Gửi lại mã" để nhận mã mới.'] };
            if (!crypto.timingSafeEqual(Buffer.from(sha256(`${u.id}:${code}`)), Buffer.from(v.code_hash))) {
                db.prepare('UPDATE verify_codes SET attempts = attempts + 1 WHERE user_id = ?').run(u.id);
                return { err: [400, 'Mã không đúng.'] };
            }
            db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(u.id);
            db.prepare('DELETE FROM verify_codes WHERE user_id = ?').run(u.id);
            return { ok: Object.assign({ token: createSession(u.id) }, userInfo(u)) };
        });
        if (res.err) throw new HttpError(res.err[0], res.err[1]);
        return res.ok;
    },

    'POST /api/resend': ({ body, ip }) => {
        rateLimit(`resend:${ip}`, 10, 60 * 60 * 1000);
        const u = db.prepare('SELECT * FROM users WHERE username = ? AND email_verified = 0').get(String(body.username || '').trim());
        if (u) {
            rateLimit(`resend-u:${u.id}`, 5, 60 * 60 * 1000);
            issueVerifyCode(u);
        }
        return { sent: true };                                         // luôn trả lời giống nhau
    },

    // Quên mật khẩu: luôn trả lời giống nhau dù email có tồn tại hay không (không cho dò email).
    'POST /api/forgot': ({ body, ip }) => {
        rateLimit(`forgot:${ip}`, 5, 15 * 60 * 1000);
        const email = cleanEmail(body.email);
        rateLimit(`forgot-mail:${email}`, 3, 60 * 60 * 1000);
        const u = db.prepare('SELECT id, username FROM users WHERE email = ? COLLATE NOCASE').get(email);
        if (u) {
            const token = crypto.randomBytes(32).toString('hex');
            tx(() => {
                db.prepare('DELETE FROM reset_tokens WHERE user_id = ?').run(u.id);
                db.prepare('INSERT INTO reset_tokens (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)').run(sha256(token), u.id, Date.now() + RESET_TTL_MS, Date.now());
            });
            void sendMail(email, `${SITE_NAME}: đặt lại mật khẩu`,
                `Xin chào ${u.username},\n\nBạn (hoặc ai đó) vừa yêu cầu đặt lại mật khẩu.\nBấm vào link dưới đây (có hiệu lực ${RESET_TTL_MS / 60000} phút, dùng 1 lần):\n\n${PUBLIC_URL}/#reset=${token}\n\nNếu không phải bạn, hãy bỏ qua thư này, mật khẩu của bạn vẫn an toàn.`);
        }
        return { sent: true };
    },

    'POST /api/reset': ({ body, ip }) => {
        rateLimit(`reset:${ip}`, 10, 15 * 60 * 1000);
        const token = String(body.token || '');
        const password = String(body.password || '');
        if (!/^[a-f0-9]{64}$/.test(token)) throw new HttpError(400, 'Link đặt lại mật khẩu không hợp lệ.');
        return tx(() => {
            const r = db.prepare('SELECT t.user_id, t.expires_at, u.username FROM reset_tokens t JOIN users u ON u.id = t.user_id WHERE t.token_hash = ?').get(sha256(token));
            if (!r || r.expires_at < Date.now()) throw new HttpError(400, 'Link đã hết hạn hoặc đã được dùng. Hãy yêu cầu link mới.');
            checkPassword(password, r.username);
            db.prepare('DELETE FROM reset_tokens WHERE user_id = ?').run(r.user_id);
            setPassword(r.user_id, password);
            db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(r.user_id);   // bấm được link trong thư = sở hữu email
            db.prepare('DELETE FROM sessions WHERE user_id = ?').run(r.user_id);      // đăng xuất mọi thiết bị
            return {};
        });
    },

    // Báo số ván thắng mới để lên bảng xếp hạng tuần. Giới hạn: tối đa 100/lần, 800/ngày (1 ván/phút nên không thể hơn).
    // ===== Chơi game: mọi thay đổi vàng/hạng do server tính =====
    'GET /api/state': withAuth(({ req, user }) => gameCall(user, req, null)),
    'POST /api/pick': withAuth(({ req, user, body }) => gameCall(user, req, (p, now, cur, room) => {
        const color = body.color === null ? null : String(body.color || '');
        game.pick(p, room, cur, color, color === null ? 0 : toInt(body.stake), now);
    })),
    'POST /api/daily': withAuth(({ req, user }) => gameCall(user, req, (p, now) => ({ events: game.claimDaily(p, now) }))),
    'POST /api/wheel': withAuth(({ req, user, body }) => gameCall(user, req, (p, now) => game.spinWheel(p, toInt(body.stake), now, undefined, isFairUser(user)))),
    'POST /api/mission': withAuth(({ req, user, body }) => gameCall(user, req, (p, now) => ({ events: game.claimMission(p, String(body.id || ''), now) }))),
    'POST /api/skin': withAuth(({ req, user, body }) => gameCall(user, req, (p) => { game.useSkin(p, String(body.id || '')); })),
    'POST /api/code': withAuth(({ req, user, body }) => {
        rateLimit(`code:${user.id}`, 20, 60 * 1000);
        return gameCall(user, req, (p) => ({ delta: game.redeemCode(p, body.code) }));
    }),
    'POST /api/stars/buy': withAuth(({ req, user, body }) => {
        rateLimit(`mint:${user.id}`, 60, 60 * 1000);
        const qty = toInt(body.qty);
        if (!Number.isFinite(qty) || qty < 1 || qty > MINT_MAX_PER_CALL) throw new HttpError(400, `Số sao mỗi lần từ 1 đến ${MINT_MAX_PER_CALL}.`);
        return gameCall(user, req, (p) => {
            const used = db.prepare("SELECT COALESCE(SUM(delta), 0) AS s FROM star_log WHERE user_id = ? AND kind = 'mint' AND at > ?").get(user.id, Date.now() - DAY_MS).s;
            if (used + qty > MINT_DAILY_LIMIT) throw new HttpError(429, `Đã chạm giới hạn ${MINT_DAILY_LIMIT} sao mỗi 24 giờ.`);
            game.spendForStars(p, qty);
            addStars(user.id, qty, 'mint', null);
        });
    }),

    // Kết quả các ván ĐÃ kết thúc (ván đang chạy và tương lai không bao giờ được trả về)
    'GET /api/results': ({ req, ip }) => {
        rateLimit(`res:${ip}`, 300, 60 * 1000);
        const u = new URL(String(req.url).replace(/^\/{2,}/, '/'), 'http://localhost');
        const room = String(u.searchParams.get('room') || 'chung').trim().slice(0, 24) || 'chung';
        const now = Date.now();
        const cur = Math.floor(now / ROUND_MS);
        let to = parseInt(u.searchParams.get('to'), 10);
        let from = parseInt(u.searchParams.get('from'), 10);
        if (!Number.isFinite(to) || to > cur - 1) to = cur - 1;
        if (!Number.isFinite(from) || from < to - 199) from = to - 199;
        from = Math.max(0, from);
        const results = {};
        for (let k = from; k <= to; k++) results[k] = diceFor(room, k);
        return { now, cur, results };
    },
    'GET /api/leaderboard': withAuth(({ user }) => {
        const wk = vnWeekKey();
        const top = db.prepare(`SELECT u.username, l.wins FROM lb_week l JOIN users u ON u.id = l.user_id
            WHERE l.week = ? AND l.wins > 0 AND u.username NOT LIKE 'deleted\_%' ESCAPE '\\'
            ORDER BY l.wins DESC, l.updated_at ASC LIMIT 10`).all(wk);
        const mine = db.prepare('SELECT wins FROM lb_week WHERE week = ? AND user_id = ?').get(wk, user.id);
        let me = null;
        if (mine && mine.wins > 0) {
            const rank = db.prepare('SELECT COUNT(*) AS n FROM lb_week WHERE week = ? AND wins > ?').get(wk, mine.wins).n + 1;
            me = { rank, wins: mine.wins };
        }
        const ends = Date.parse(wk + 'T00:00:00Z') - 7 * 3600 * 1000 + 7 * 86400000;
        return { top, me, week_ends_at: ends };
    }),

    'POST /api/logout': withAuth(({ user }) => {
        db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(user.token));
        return {};
    }),

    'GET /api/me': withAuth(({ user }) => {
        tx(() => expireGifts(Date.now()));
        return userInfo(db.prepare('SELECT username, stars, email, marketing_ok FROM users WHERE id = ?').get(user.id));
    }),

    // Cập nhật email khôi phục (phải nhập mật khẩu hiện tại) và/hoặc đồng ý nhận ưu đãi.
    'POST /api/profile': withAuth(({ user, body }) => {
        rateLimit(`profile:${user.id}`, 20, 10 * 60 * 1000);
        if (body.email !== undefined) {
            const row = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
            if (!verifyPassword(row, String(body.password || ''))) throw new HttpError(403, 'Mật khẩu hiện tại không đúng.');
            const email = cleanEmail(body.email);
            try { db.prepare('UPDATE users SET email = ? WHERE id = ?').run(email, user.id); }
            catch (e) { if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'Email này đã được dùng cho tài khoản khác.'); throw e; }
        }
        if (body.marketing !== undefined) db.prepare('UPDATE users SET marketing_ok = ? WHERE id = ?').run(body.marketing === true ? 1 : 0, user.id);
        return userInfo(db.prepare('SELECT username, stars, email, marketing_ok FROM users WHERE id = ?').get(user.id));
    }),

    // Đổi mật khẩu: các thiết bị khác bị đăng xuất.
    'POST /api/password': withAuth(({ user, body }) => {
        rateLimit(`pw:${user.id}`, 8, 15 * 60 * 1000);
        const row = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
        if (!verifyPassword(row, String(body.oldPassword || ''))) throw new HttpError(403, 'Mật khẩu hiện tại không đúng.');
        const pw = String(body.newPassword || '');
        checkPassword(pw, row.username);
        tx(() => {
            setPassword(user.id, pw);
            db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').run(user.id, sha256(user.token));
        });
        return {};
    }),

    // Xoá tài khoản: gỡ email và mật khẩu, đăng xuất mọi nơi. (Sổ cái sao giữ lại dưới tên ẩn danh.)
    'POST /api/account/delete': withAuth(({ user, body }) => {
        rateLimit(`del:${user.id}`, 5, 15 * 60 * 1000);
        const row = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
        if (!verifyPassword(row, String(body.password || ''))) throw new HttpError(403, 'Mật khẩu không đúng.');
        tx(() => {
            // huỷ các code còn mở của chính người này (hoàn sao) trước khi xoá
            for (const g of db.prepare("SELECT code, amount FROM gifts WHERE from_user = ? AND status = 'open'").all(user.id)) {
                if (db.prepare("UPDATE gifts SET status = 'cancelled' WHERE code = ? AND status = 'open'").run(g.code).changes === 1) addStars(user.id, g.amount, 'gift_refund', g.code);
            }
            const salt = crypto.randomBytes(16).toString('hex');
            db.prepare('UPDATE users SET username = ?, email = NULL, phone = NULL, marketing_ok = 0, pass_salt = ?, pass_hash = ? WHERE id = ?')
                .run(`deleted_${user.id}`, salt, hashPassword(crypto.randomBytes(16).toString('hex'), salt), user.id);
            db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);
            db.prepare('DELETE FROM reset_tokens WHERE user_id = ?').run(user.id);
        });
        return {};
    }),

    // Nhận thêm sao khi người chơi dùng vàng mua sao (vàng hiện còn nằm trên máy người chơi → tạm tin máy khách, có hạn mức mỗi ngày).
    // Tạo code tặng: trừ sao của người tạo ngay lúc tạo.
    'POST /api/gifts': withAuth(({ user, body }) => {
        rateLimit(`gift:${user.id}`, 20, 60 * 1000);
        const amount = toInt(body.amount);
        if (!Number.isFinite(amount) || amount < 1) throw new HttpError(400, 'Nhập số sao muốn tặng (ít nhất 1).');
        if (amount > GIFT_MAX_PER_CODE) throw new HttpError(400, `Mỗi code tặng tối đa ${GIFT_MAX_PER_CODE} sao.`);
        return tx(() => {
            const now = Date.now();
            expireGifts(now);
            const used = db.prepare("SELECT COALESCE(SUM(amount), 0) AS s FROM gifts WHERE from_user = ? AND created_at > ? AND status IN ('open', 'redeemed')").get(user.id, now - GIFT_WINDOW_MS).s;
            if (used + amount > GIFT_DAILY_LIMIT) {
                const first = db.prepare("SELECT MIN(created_at) AS t FROM gifts WHERE from_user = ? AND created_at > ? AND status IN ('open', 'redeemed')").get(user.id, now - GIFT_WINDOW_MS).t || now;
                const mins = Math.max(1, Math.ceil((first + GIFT_WINDOW_MS - now) / 60000));
                const wait = mins >= 60 ? `${Math.floor(mins / 60)} giờ ${mins % 60} phút` : `${mins} phút`;
                throw new HttpError(429, `Chỉ được tặng tối đa ${GIFT_DAILY_LIMIT} sao mỗi 2 giờ (đã tặng ${used}). Hãy đợi khoảng ${wait}.`);
            }
            let code;
            for (let i = 0; i < 5; i++) {
                const c = newCode();
                if (!db.prepare('SELECT 1 FROM gifts WHERE code = ?').get(c)) { code = c; break; }
            }
            if (!code) throw new HttpError(500, 'Không tạo được code, hãy thử lại.');
            addStars(user.id, -amount, 'gift_create', code);
            db.prepare('INSERT INTO gifts (code, from_user, amount, created_at, expires_at) VALUES (?, ?, ?, ?, ?)').run(code, user.id, amount, now, now + GIFT_TTL_MS);
            return { code, amount, expires_at: now + GIFT_TTL_MS, stars: getStars(user.id) };
        });
    }),

    // Danh sách code tôi đã tạo (kèm trạng thái).
    'GET /api/gifts': withAuth(({ user }) => tx(() => {
        expireGifts(Date.now());
        const gifts = db.prepare(`
            SELECT g.code, g.amount, g.status, g.created_at, g.expires_at, u.username AS redeemed_by
            FROM gifts g LEFT JOIN users u ON u.id = g.redeemed_by
            WHERE g.from_user = ? ORDER BY g.created_at DESC LIMIT 20`).all(user.id);
        return { gifts, stars: getStars(user.id) };
    })),

    // Nhận sao từ code: đánh dấu đã dùng + cộng sao trong cùng một giao dịch → không thể dùng 2 lần.
    'POST /api/gifts/redeem': withAuth(({ user, body }) => {
        rateLimit(`redeem:${user.id}`, 15, 60 * 1000);
        const code = normalizeCode(body.code);
        if (!code) throw new HttpError(400, 'Code không đúng định dạng (ví dụ SAO-ABCD-2345).');
        return tx(() => {
            const now = Date.now();
            expireGifts(now);
            const g = db.prepare('SELECT g.code, g.from_user, g.amount, g.status, u.username AS from_name FROM gifts g JOIN users u ON u.id = g.from_user WHERE g.code = ?').get(code);
            if (!g) throw new HttpError(404, 'Code không tồn tại.');
            if (g.status === 'expired') throw new HttpError(410, 'Code đã hết hạn.');
            if (g.status !== 'open') throw new HttpError(410, 'Code này đã được sử dụng hoặc đã bị huỷ.');
            if (g.from_user === user.id) throw new HttpError(400, 'Bạn không thể tự nhận code do chính mình tạo (hãy dùng nút Huỷ để lấy lại sao).');
            const r = db.prepare("UPDATE gifts SET status = 'redeemed', redeemed_by = ?, redeemed_at = ? WHERE code = ? AND status = 'open'").run(user.id, now, code);
            if (r.changes !== 1) throw new HttpError(410, 'Code này đã được sử dụng.');
            addStars(user.id, g.amount, 'gift_redeem', code);
            return { amount: g.amount, from: g.from_name, stars: getStars(user.id) };
        });
    }),

    // Người tạo huỷ code chưa ai nhận → hoàn sao.
    'POST /api/gifts/cancel': withAuth(({ user, body }) => {
        rateLimit(`cancel:${user.id}`, 20, 60 * 1000);
        const code = normalizeCode(body.code);
        if (!code) throw new HttpError(400, 'Code không đúng định dạng.');
        return tx(() => {
            expireGifts(Date.now());
            const g = db.prepare('SELECT code, from_user, amount, status FROM gifts WHERE code = ?').get(code);
            if (!g || g.from_user !== user.id) throw new HttpError(404, 'Không tìm thấy code của bạn.');
            if (g.status !== 'open') throw new HttpError(400, 'Code này không còn ở trạng thái chờ nhận.');
            const r = db.prepare("UPDATE gifts SET status = 'cancelled' WHERE code = ? AND status = 'open'").run(code);
            if (r.changes !== 1) throw new HttpError(400, 'Code này không còn ở trạng thái chờ nhận.');
            addStars(user.id, g.amount, 'gift_refund', code);
            return { stars: getStars(user.id) };
        });
    })
};

/* ===================== Máy chủ HTTP ===================== */
function readJson(req) {
    return new Promise((resolve, reject) => {
        let size = 0;
        const chunks = [];
        req.on('data', (c) => {
            size += c.length;
            if (size > 8 * 1024) { reject(new HttpError(413, 'Dữ liệu gửi lên quá lớn.')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', () => {
            if (!chunks.length) return resolve({});
            try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')) || {}); }
            catch (_) { reject(new HttpError(400, 'Dữ liệu không phải JSON hợp lệ.')); }
        });
        req.on('error', reject);
    });
}

function send(res, status, body, headers) {
    const sec = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer' };
    if (TRUST_PROXY) sec['Strict-Transport-Security'] = 'max-age=31536000';
    res.writeHead(status, Object.assign(sec, headers));
    res.end(body);
}
const sendJson = (res, status, obj) => send(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8' });

// Thư mục chứa trang web: ./public nếu có, không thì cùng thư mục với server.js (bản phẳng để tải lên từ điện thoại)
const PUB_DIR = fs.existsSync(path.join(__dirname, 'public')) ? path.join(__dirname, 'public') : __dirname;
const INDEX_FILE = path.join(PUB_DIR, 'index.html');

const server = http.createServer(async (req, res) => {
    try {
        if (ALLOW_ORIGIN) {
            res.setHeader('Access-Control-Allow-Origin', ALLOW_ORIGIN);
            res.setHeader('Vary', 'Origin');
            res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        }
        if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

        let url;
        try { url = new URL(String(req.url).replace(/^\/{2,}/, '/'), 'http://localhost'); }
        catch (_) { throw new HttpError(400, 'Đường dẫn không hợp lệ.'); }
        if (url.pathname.startsWith('/api/')) {
            const handler = routes[`${req.method} ${url.pathname}`];
            if (!handler) throw new HttpError(404, 'Không tìm thấy.');
            const body = req.method === 'POST' ? await readJson(req) : {};
            const result = await handler({ req, body, ip: clientIp(req) });
            sendJson(res, 200, Object.assign({ ok: true }, result));
            return;
        }
        if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
            send(res, 200, fs.readFileSync(INDEX_FILE), { 'Content-Type': 'text/html; charset=utf-8' });
            return;
        }
        if (req.method === 'GET' && (url.pathname === '/terms' || url.pathname === '/privacy')) {
            const page = fs.readFileSync(path.join(PUB_DIR, url.pathname.slice(1) + '.html'), 'utf8')
                .replaceAll('{{CONTACT_EMAIL}}', CONTACT_EMAIL).replaceAll('{{SITE_NAME}}', SITE_NAME);
            send(res, 200, page, { 'Content-Type': 'text/html; charset=utf-8' });
            return;
        }
        const bgm = req.method === 'GET' && /^\/bg(\d{1,2})\.(jpg|png|webp)$/.exec(url.pathname);
        if (bgm) {   // ảnh nền trình chiếu: bg1.jpg … bg20.jpg đặt cùng thư mục với index.html
            let buf;
            try { buf = fs.readFileSync(path.join(PUB_DIR, url.pathname.slice(1))); } catch (_) { throw new HttpError(404, 'Không tìm thấy.'); }
            send(res, 200, buf, { 'Content-Type': { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' }[bgm[2]], 'Cache-Control': 'public, max-age=86400' });
            return;
        }
        if (req.method === 'GET' && url.pathname === '/healthz') { send(res, 200, 'ok', { 'Content-Type': 'text/plain' }); return; }
        throw new HttpError(404, 'Không tìm thấy.');
    } catch (e) {
        const status = e.status || 500;
        if (status === 500) console.error(e);
        sendJson(res, status, Object.assign({ ok: false, error: status === 500 ? 'Lỗi máy chủ.' : e.message }, status === 500 ? {} : (e.extra || {})));
    }
});

if (require.main === module) {
    // dọn phiên đăng nhập quá hạn mỗi giờ
    setInterval(() => {
        try {
            db.prepare('DELETE FROM sessions WHERE created_at < ?').run(Date.now() - SESSION_TTL_MS);
            db.prepare('DELETE FROM reset_tokens WHERE expires_at < ?').run(Date.now());
            db.prepare('DELETE FROM users WHERE email_verified = 0 AND created_at < ?').run(Date.now() - 24 * 3600 * 1000);   // đăng ký bỏ dở
        } catch (_) { /* bỏ qua */ }
    }, 3600 * 1000).unref();
    // TEST_ACCOUNTS=1: tạo sẵn tài khoản thử (đã xác minh). CHỈ dùng khi thử nghiệm, tắt biến này trước khi mở công khai.
    if (process.env.TEST_ACCOUNTS === '1') {
        const pw = process.env.TEST_PASSWORD || '123456';
        const salt = crypto.randomBytes(16).toString('hex');
        const now = Date.now();
        db.prepare('INSERT OR IGNORE INTO users (username, email, phone, marketing_ok, terms_at, pass_salt, pass_hash, created_at, email_verified) VALUES (?, ?, ?, 0, ?, ?, ?, ?, 1)')
            .run('testplayer', 'testplayer@example.invalid', '840000000001', now, salt, hashPassword(pw, salt), now);
        console.log('Đã tạo tài khoản thử: testplayer /', pw);
    }
    turso.start(db);
    server.listen(PORT, () => console.log(`Game Vui Quà Khủng chạy tại http://localhost:${PORT}`));
}

module.exports = { server, db };
