# Đưa game lên mạng (link `guyisgayy`)

Server là một ứng dụng Node (>= 22.5) kèm file SQLite, nên cần chỗ chạy có **ổ đĩa lưu dữ liệu**.
Nếu không có ổ đĩa, mỗi lần khởi động lại sẽ mất toàn bộ tài khoản và code.

## Cách 1: Render (dễ nhất, ~7 USD/tháng vì cần ổ đĩa)
1. Tạo tài khoản GitHub, tạo repo mới, tải thư mục `xucxac-server` lên (có sẵn `Dockerfile`, `render.yaml`).
2. Vào render.com > New > Blueprint > chọn repo. Render đọc `render.yaml` và tự dựng.
3. Đặt tên dịch vụ `guyisgayy` thì link sẽ là `https://guyisgayy.onrender.com`
   (nếu tên đã có người dùng, Render sẽ thêm hậu tố ngẫu nhiên).

## Cách 2: Fly.io hoặc Railway
Cùng `Dockerfile`, gắn volume vào `/data`, đặt `TRUST_PROXY=1`.

## Cách 3: VPS (rẻ nhất khi lớn)
```
git clone <repo> && cd xucxac-server
docker build -t xucxac .
docker run -d --restart=always -p 3000:3000 -v xucxac-data:/data \
  -e PUBLIC_URL=https://guyisgayy.duckdns.org -e CONTACT_EMAIL=email-cua-ban@gmail.com xucxac
```
Đặt Caddy hoặc Nginx phía trước để có https.

## Dùng tên miền riêng, ví dụ `guyisgayy.com`
1. Mua tên miền (Namecheap, Porkbun, khoảng 10 USD/năm). Tên miền Việt `.vn` cần giấy tờ.
2. Trong trang quản lý dịch vụ (Render: Settings > Custom Domains) thêm tên miền đó.
3. Ở nơi mua tên miền, tạo bản ghi DNS (CNAME) theo đúng hướng dẫn dịch vụ hiển thị.
4. Chờ vài phút đến vài giờ, https tự bật.

## Kiểm tra
- Mở `https://<link của bạn>/healthz` phải thấy `ok`.
- Mở link gốc phải ra game, đăng ký tài khoản được.

## Trước khi công khai
- Xóa code thử `test`, `nocode` trong game (biến `CODES`).
- Sao lưu file `/data/data.sqlite` định kỳ.
- Gold và kết quả vòng vẫn chạy trên máy người chơi nên có thể bị gian lận; đây là phần cần làm tiếp nếu bạn muốn nghiêm túc.

## Email: quên mật khẩu, thu thập thông tin, bán gói tháng
Game giờ bắt người đăng ký nhập email (để lấy lại mật khẩu) và có ô tích tùy chọn "nhận ưu đãi/gói tháng".

**Biến môi trường (đặt khi chạy server)**
| Biến | Ý nghĩa |
|---|---|
| `PUBLIC_URL` | Địa chỉ công khai của game, dùng làm link trong thư đặt lại mật khẩu. **Bắt buộc đặt đúng.** |
| `CONTACT_EMAIL` | Email liên hệ hiện trong trang Điều khoản và Chính sách bảo mật |
| `SITE_NAME` | Tên hiện trong thư và trang pháp lý |
| `MAIL_FROM` + `BREVO_API_KEY` | Gửi thư qua Brevo (gói miễn phí khoảng 300 thư/ngày, gửi được từ một email đã xác minh, không cần tên miền riêng) |
| `MAIL_FROM` + `RESEND_API_KEY` | Hoặc gửi qua Resend (cần tên miền riêng đã xác minh) |

Chưa đặt `MAIL_FROM` và khoá API thì thư **chỉ in ra nhật ký server** (`docker logs xucxac`), người dùng sẽ không nhận được gì. Muốn tính năng quên mật khẩu hoạt động thật, bạn phải cấu hình một trong hai.
Cách làm với Brevo: đăng ký brevo.com, vào Senders để xác minh email gửi, tạo API key (SMTP & API), rồi chạy lại container với `-e MAIL_FROM=... -e BREVO_API_KEY=...`. Thư có thể rơi vào mục thư rác nếu gửi từ Gmail cá nhân, nên về lâu dài nên dùng tên miền riêng.

**Lấy danh sách email để bán gói tháng**
```
sudo docker exec xucxac node export-emails.js > emails.csv        # chỉ người đã tích đồng ý nhận ưu đãi
sudo docker exec xucxac node export-emails.js --all > tat-ca.csv  # tất cả (chỉ dùng gửi thư dịch vụ)
```
Chỉ gửi quảng bá cho người đã tích đồng ý, và mỗi thư quảng bá phải có cách hủy nhận. Nhiều nơi (Canada có luật CASL, EU có GDPR, Mỹ có CAN-SPAM) phạt nặng gửi thư rác. Hai trang `/terms` và `/privacy` là bản mẫu, bạn nên nhờ luật sư rà lại.

## Bảo vệ tài khoản (đã có sẵn)
- Mật khẩu băm scrypt, tối thiểu 8 ký tự, từ chối mật khẩu quá dễ đoán.
- Sai mật khẩu 5 lần thì khóa tài khoản 15 phút; giới hạn số lần đăng nhập, đăng ký, quên mật khẩu theo IP và theo email.
- Link đặt lại mật khẩu: dùng 1 lần, hết hạn sau 30 phút, chỉ lưu bản băm; đặt lại xong mọi thiết bị bị đăng xuất.
- Đổi mật khẩu hoặc email cần nhập mật khẩu hiện tại. Người dùng tự xóa được tài khoản.
- Việc cần bạn làm: dùng https (Caddy ở trên), sao lưu file `data.sqlite`, giữ kín khóa API gửi thư.

## Xác minh email khi đăng ký (bắt buộc)
Đăng ký xong, người chơi phải nhập mã 6 số gửi tới email mới dùng được tài khoản (mã hiệu lực 15 phút, nhập sai quá 5 lần phải xin mã mới, tài khoản chưa xác minh bị xóa sau 24 giờ).
- **Muốn gửi thư thật:** cấu hình `MAIL_FROM` + `BREVO_API_KEY` (xem mục Email ở trên).
- **Chưa cấu hình thư:** mã chỉ in ra nhật ký (Render: tab Logs, tìm "mã xác minh"). Người chơi thật sẽ không nhận được mã.
- **Chỉ để thử nghiệm:** đặt biến `SKIP_EMAIL_VERIFY=1` để bỏ bước xác minh. **Xóa biến này trước khi mở cho người chơi thật.**

## Tài khoản test & số điện thoại quốc tế (v34)
- Đăng ký chọn quốc gia (242 quốc gia/vùng lãnh thổ, mặc định Việt Nam +84); server lưu dạng số quốc tế (E.164).
- `TEST_ACCOUNTS=1` tạo sẵn tài khoản đã xác minh: `testplayer` / `123456` (đổi bằng `TEST_PASSWORD`).
  **Xoá biến này trước khi mở công khai.**

## Kết quả xúc xắc do server tạo (v45)
- App không còn tự tính kết quả. Server tạo bằng khoá bí mật (HMAC-SHA256) và chỉ công bố các ván **đã kết thúc** (`GET /api/results`).
- Đặt biến `RESULT_SECRET` (chuỗi ngẫu nhiên dài) trên Render để kết quả cũ không đổi khi server khởi động lại. Không đặt thì server tự sinh khoá và lưu trong cơ sở dữ liệu (mất khoá nếu mất dữ liệu).
- Vàng, rank vẫn tính trên máy người chơi cho đến khi chuyển phần chấm thắng thua sang server.

## Server chấm thắng thua (v46)
- Vàng, hạng, mưa vàng, nhiệm vụ, điểm danh, skin, code và mua sao của **tài khoản** do server tính và lưu (bảng `pstate`). App chỉ hiển thị, sửa trên máy không đổi được gì.
- Khách chưa đăng nhập vẫn chơi thử trên máy (10 vàng). Khi đăng ký, vàng chơi thử được mang theo tối đa `GUEST_MAX_CARRY` (mặc định 100); hạng/lãi không mang theo.
- Code thử (`test`, `nocode`, `newbie`) nằm trong `game.js`; đặt `DISABLE_TEST_CODES=1` để tắt hẳn trước khi phát hành.
- Đã bỏ `/api/score` và `/api/stars/mint`; thay bằng `/api/state`, `/api/pick`, `/api/daily`, `/api/mission`, `/api/skin`, `/api/code`, `/api/stars/buy`.
- Dữ liệu vẫn nằm trong file SQLite của Render: bản miễn phí sẽ mất khi khởi động lại cho tới khi nối Turso hoặc dùng ổ đĩa trả phí.

## Giữ dữ liệu khi Render khởi động lại (Turso)
Thêm 2 biến môi trường trên Render: `TURSO_URL` (dạng `libsql://...turso.io`) và `TURSO_TOKEN`.
- Khởi động: server tải dữ liệu từ Turso về. Nếu không kết nối được thì server dừng (không chạy bằng database rỗng).
- Đang chạy: cứ 10 giây, bảng nào đổi thì sao lưu lên Turso; khi Render tắt (SIGTERM) sẽ sao lưu nốt.
- Giới hạn: nếu server sập đột ngột, có thể mất tối đa ~10 giây dữ liệu gần nhất. Chỉ chạy 1 bản server (không chạy nhiều bản cùng lúc).
- Không đưa token vào GitHub.

## Vòng quay may mắn (v47)
- Game thứ 2 trong Menu game (🎡). Endpoint: `POST /api/wheel` {stake}. Server quay, trả `wheel: {cell, mult, stake, delta}` và trạng thái mới.
- 14 ô: 9 thưởng (x1, x1,5, x2, x2,5, x4, x5, x6,1, x6,2, x8) và 5 phạt (x-1, x-1,5, x-2, x-2,5, x-5), xếp lộn xộn. 50% trúng xanh / 50% trúng đỏ.
- Trong mỗi màu, ô lớn hiếm hơn (trọng số ở `WHEEL_W` trong game.js), kỳ vọng ≈ hoà vốn. Mất tối đa bằng số vàng đang có.
- Cược 1–1000, không vượt số dư (đã trừ phần đang cược xúc xắc); mỗi lần quay cách nhau ≥ 2,5 giây.
- Cần đăng nhập để quay. Vòng quay không tính vào bảng xếp hạng tuần.
- Cơ hội trúng ô xanh theo hạng (WHEEL_GREEN_BY_RANK trong game.js): Tân binh 50%, Đồng 48%, Bạc 46%, Vàng 44%, Kim cương 42%, Cao thủ 30%.
- Tài khoản `testplayer` (khi `TEST_ACCOUNTS=1`) luôn 50/50 bất kể hạng, để thử nghiệm. Xóa `TEST_ACCOUNTS` trước khi mở công khai.
- Chuỗi xanh liên tiếp: 3 lần → xanh tối đa 35%; 5 lần trở lên → tối đa 15% (lấy mức thấp hơn giữa hạng và chuỗi; trúng đỏ thì chuỗi về 0). `testplayer` bỏ qua cả chuỗi, luôn 50/50.

## Điều chỉnh lãi/lỗ theo số dư (v56, cả Xúc xắc và Vòng quay)
- Mốc đích T = bội kế tiếp của 80 lớn hơn số dư (80, 160, 240...). Hệ thống chỉ BẬT khi ví đạt 6/8 (75%) của T: ví 60 với T=80; 120 với T=160; 180 với T=240...
- Từ ngưỡng tới T: hệ số lãi giảm từ x1 xuống tối thiểu x0,2; hệ số lỗ tăng từ x1 lên tối đa **x2**. Có độ ngẫu nhiên nhỏ; trong một chu kỳ chỉ giảm (lãi)/chỉ tăng (lỗ). Ví vượt T thì tính lại. Dưới ngưỡng: lãi x1, lỗ x1.
- Lỗ còn nhân theo mức cược (cược 10 → x1, cược ≥500 → x2) và theo hạng (mỗi hạng nhân thêm 2: x1, x2, x4, x8, x16, x32) — luôn áp dụng, không phụ thuộc ngưỡng. Lãi chỉ theo hạng. Mọi khoản lỗ không vượt số vàng đang có.
- Chỉnh các hằng số trong `game.js`: SQ_START, SQ_GAIN_PTS, SQ_LOSS_PTS, stakeLossMult, rankLossMult.
- `GAME_NO_SQUEEZE=1` chỉ để chạy bài kiểm tra cũ. KHÔNG đặt trên Render.
- Nút cược nhanh: Xúc xắc 1, 2, 5, 10, 50, 100, 500, 1000, Tối đa; Vòng quay 1, 2, 5, 10, 50, 100, Tất cả.
- Âm thanh: khi mất từ 50% số vàng đang có trở lên ở xúc xắc hoặc vòng quay, app phát file âm thanh nhúng sẵn trong index.html (LOSS_SOUND, mp3 do người dùng cung cấp, ~40KB); nếu trình duyệt không phát được thì dùng tiếng kèn tạo bằng Web Audio.
- Nhạc thắng: mỗi lần thắng (xúc xắc đoán đúng, vòng quay trúng ô xanh) phát đoạn nhạc 12 giây nhúng sẵn (WIN_SOUND, mp3 do người dùng cung cấp, ~97KB). Không phát chồng; tiếng mất vàng lớn sẽ dừng nhạc thắng.
- Vòng quay hiển thị bằng hình (không ghi số): 1 đồng, 5 đồng, chồng/đống đồng, túi vàng, hai túi, đống+túi, đống+kim cương, đống kim cương cho 9 ô thưởng; đồng xu nứt, tiền bay (💸), kẻ cướp (🦹), bom (💣), đầu lâu (💀) cho 5 ô phạt. Sửa trong WHEEL_ICON (index.html).
- Code thử (tắt khi DISABLE_TEST_CODES=1): `test` +10, `test100` +100, `test1000` +1000 (dùng không giới hạn, gõ có hoặc không có khoảng trắng và hoa/thường đều được), `nocode` −10, `newbie` +100 (một lần).

## Mưa vàng x50 (v59)
Mưa vàng = 50 × tiền cược ván thắng (cược 10 → +500). Đổi ở game.js (RAIN_BONUS) và giao diện.

## Giới hạn tặng sao (v60)
Mỗi code 1–10 sao; tối đa 10 sao / 2 giờ / người (env GIFT_MAX_PER_CODE, GIFT_DAILY_LIMIT, GIFT_WINDOW_HOURS). Quá hạn mức báo lỗi kèm thời gian chờ. Sửa lỗi demo hiện 'undefined' khi tạo code.

## Đổi tên (v61)
Tên game: 'Game Vui Quà Khủng', slogan 'Chơi lớn quà lớn, chơi khủng quà khủng', chữ LED RGB (class led-rgb trong index.html). Tên trong email lấy từ SITE_NAME (mặc định đã đổi; nếu Render có đặt SITE_NAME thì sửa ở đó).

## Nền trình chiếu (v62)
Đặt ảnh bg1.jpg … bg20.jpg (hoặc .png/.webp) cùng chỗ với index.html trong zip. Game tự nạp, mỗi ảnh hiện 4 giây, chuyển bằng hiệu ứng mờ dần 1,5 giây, độ đậm 90% (ảnh mờ nhẹ 10%; đổi trong index.html: setInterval 4000 và transition 1.5s). Thiếu ảnh nào thì bỏ qua, không có ảnh nào thì không hiện nền. Nên nén mỗi ảnh < 300KB (ngang ~720px).

Ảnh nền bg1.jpg: do người dùng xác nhận là ảnh miễn phí cho dùng thương mại (nguồn/giấy phép cụ thể chưa được cung cấp cho tôi; nên lưu lại link nguồn và xác nhận của luật sư).

## Hộp thư + Hỗ trợ khách hàng (v63)
- Giao diện: nút ✉️ (Hộp thư, có chấm đỏ số thư chưa đọc) và 🎧 (Hỗ trợ) ở đầu trang.
- Hộp thư: mỗi người tối đa 100 thư, có thư chào mừng khi đăng ký. Hỗ trợ: câu hỏi thường gặp + form gửi yêu cầu (tối đa 5 yêu cầu / giờ / người, 1000 ký tự).
- Lưu trong 2 bảng mới `mail`, `support`, tự sao lưu lên Turso.
- Biến môi trường mới (tùy chọn): `ADMIN_KEY` (bật API quản trị), `SUPPORT_URL` (link Telegram/Facebook hỗ trợ), `CONTACT_EMAIL` (email hiện trong phần Hỗ trợ).
- API quản trị (gửi kèm header `x-admin-key: <ADMIN_KEY>`):
  - `GET /api/admin/support` xem các yêu cầu hỗ trợ.
  - `POST /api/admin/mail` body `{"to":"*" hoặc "tên", "title":"...", "body":"..."}` gửi thư cho tất cả hoặc một người.
- Không đặt `ADMIN_KEY` thì API quản trị tắt hoàn toàn (trả 404).

## v64 – Xếp hạng ngày/tuần/tháng, mời bạn, thông báo
- **Bảng xếp hạng**: tab Ngày / Tuần / Tháng (giờ VN), bảng mới `lb_period` (đã thêm vào sao lưu Turso).
- **Mời bạn bè**: link `?ref=tên_đăng_nhập`. Một bạn chỉ được tính khi đã xác minh email, số điện thoại khác người mời và khác các bạn khác. Mốc 1/3/5/10/20 bạn nhận 50/150/300/700/2000 vàng ảo (sửa ở `REF_MILESTONES` trong server.js). Không có hoa hồng, không quy đổi tiền.
- **Thông báo + popup quà đăng ký**: khách mới thấy popup 1 lần/thiết bị. Đăng thông báo:
  `curl -X POST $URL/api/admin/news -H "x-admin-key: KEY" -H "Content-Type: application/json" -d '{"title":"...","body":"..."}'` (xoá: `{"delete":ID}`).

## v65 – Poker Texas Hold'em (đấu 3 bot)
- File mới `poker.js` (tự động được sao chép cùng server.js). Mỗi ván: mua vào 20–1000 vàng, đấu 3 bot, hết ván phần còn lại về ví. Server chia bài, bot không nhìn bài người chơi, bài úp không gửi về máy.
- Ván dở vẫn giữ khi tải lại trang. Bot đoán mức EV gần hoà (người chơi thường ±4% tiền mua vào mỗi ván). Không dùng cơ chế squeeze.

## v66 – Ảnh nền tự nhận mọi ảnh
- Slideshow nay tự nhận **mọi** ảnh có tên bắt đầu bằng `bg` (jpg, jpeg, png, webp), tối đa 60 ảnh, không cần đánh số liên tục.
- Dockerfile phải sao chép đủ: đổi dòng `COPY bg*.jpg /app/` thành `COPY bg* /app/` (để lấy cả .jpeg/.png/.webp).

## v67 – Poker nhiều người thật + Poker 1 người
- **Poker nhiều người** (file mới `poker-mp.js`): bấm "GHÉP TRẬN" → hàng chờ "Đang ghép trận". Đủ 4 người thì vào bàn ngay; có từ 2 người và đã chờ ~10 giây thì vào bàn với số người đang chờ. Chỉ ghép người thật cùng mức mua vào, không bot. Tài khoản cùng số điện thoại không ngồi chung bàn.
- Mỗi lượt 25 giây, quá giờ tự động xem/bỏ bài. Rời bàn giữa ván = bỏ bài.
- Tiền mua vào trừ khỏi ví khi vào hàng chờ, hoàn lại khi hủy. Nếu server khởi động lại giữa ván, ván bị huỷ và mọi người được hoàn tiền mua vào (bảng `mp_queue`, `mp_tables` có trong sao lưu Turso).
- Trò cũ đấu 3 bot đổi tên thành **Poker 1 người**.
- Giao diện cập nhật bằng hỏi máy chủ mỗi ~1,2 giây (không cần WebSocket nên chạy được trên Render free). Lưu ý Render free ngủ sau 15 phút không có truy cập, khi đó bàn đang chơi cũng dừng.
