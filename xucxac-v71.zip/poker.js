'use strict';
// Poker Texas Hold'em: 1 người chơi + 3 bot, mỗi ván tách biệt. Server chia bài, bot không nhìn bài người khác.
// Chỉ dùng vàng ảo. Tiền mua vào (buy-in) trừ khỏi ví khi vào bàn, phần còn lại trả về ví khi hết ván.
const crypto = require('crypto');
const N = 4, MIN_BUYIN = 20, MAX_BUYIN = 1000;
const RK = '23456789TJQKA', SU = 'shdc';
const cardStr = (c) => RK[c % 13] + SU[Math.floor(c / 13)];
const rankOf = (c) => (c % 13) + 2, suitOf = (c) => Math.floor(c / 13);
const rint = (n) => crypto.randomInt(n);
const rnd = () => crypto.randomInt(1e9) / 1e9;

/* ---------- Chấm bài ---------- */
function score5(cs) {
    const r = cs.map(rankOf).sort((a, b) => b - a), flush = cs.every((c) => suitOf(c) === suitOf(cs[0]));
    const cnt = {}; r.forEach((x) => { cnt[x] = (cnt[x] || 0) + 1; });
    const groups = Object.keys(cnt).map(Number).sort((a, b) => cnt[b] - cnt[a] || b - a);
    let straight = 0;
    const u = [...new Set(r)];
    if (u.length === 5) { if (u[0] - u[4] === 4) straight = u[0]; else if (u[0] === 14 && u[1] === 5) straight = 5; }
    let cat;
    if (straight && flush) cat = 8; else if (cnt[groups[0]] === 4) cat = 7; else if (cnt[groups[0]] === 3 && cnt[groups[1]] === 2) cat = 6;
    else if (flush) cat = 5; else if (straight) cat = 4; else if (cnt[groups[0]] === 3) cat = 3;
    else if (cnt[groups[0]] === 2 && cnt[groups[1]] === 2) cat = 2; else if (cnt[groups[0]] === 2) cat = 1; else cat = 0;
    const tb = straight ? [straight] : groups;
    let s = cat; for (let i = 0; i < 5; i++) s = s * 15 + (tb[i] || 0);
    return s;
}
function best7(cs) {
    let best = -1;
    const n = cs.length;
    for (let a = 0; a < n - 4; a++) for (let b = a + 1; b < n - 3; b++) for (let c = b + 1; c < n - 2; c++) for (let d = c + 1; d < n - 1; d++) for (let e = d + 1; e < n; e++) {
        const s = score5([cs[a], cs[b], cs[c], cs[d], cs[e]]); if (s > best) best = s;
    }
    return best;
}
const CAT_NAME = ['Bài cao', 'Một đôi', 'Hai đôi', 'Sám cô', 'Sảnh', 'Thùng', 'Cù lũ', 'Tứ quý', 'Thùng phá sảnh'];
const catOf = (score) => CAT_NAME[Math.floor(score / Math.pow(15, 5))];

/* ---------- Trạng thái ---------- */
function shuffle() {
    const d = Array.from({ length: 52 }, (_, i) => i);
    for (let i = 51; i > 0; i--) { const j = rint(i + 1); [d[i], d[j]] = [d[j], d[i]]; }
    return d;
}
const live = (g) => g.folded.map((f, i) => (f ? -1 : i)).filter((i) => i >= 0);
const canAct = (g) => live(g).filter((i) => !g.allin[i]);

function start(p, buyin) {
    if (p.poker && p.poker.st === 'play') throw new Error('Bạn đang trong một ván, hãy chơi nốt.');
    if (!Number.isInteger(buyin) || buyin < MIN_BUYIN || buyin > MAX_BUYIN) throw new Error(`Tiền mua vào từ ${MIN_BUYIN} đến ${MAX_BUYIN}.`);
    const deck = shuffle(), bb = Math.max(2, Math.round(buyin / 25)), sb = Math.max(1, Math.floor(bb / 2));
    const g = {
        st: 'play', buyin, bb, sb, dealer: rint(N), deck, hole: [], board: [], stacks: Array(N).fill(buyin), bets: Array(N).fill(0), total: Array(N).fill(0),
        folded: Array(N).fill(false), allin: Array(N).fill(false), acted: Array(N).fill(false), street: 0, cur: 0, minRaise: bb, toAct: 0, raises: 0, log: [], result: null,
    };
    for (let i = 0; i < N; i++) g.hole.push([g.deck.pop(), g.deck.pop()]);
    const post = (s, amt) => { const a = Math.min(amt, g.stacks[s]); g.stacks[s] -= a; g.bets[s] += a; g.total[s] += a; if (!g.stacks[s]) g.allin[s] = true; };
    post((g.dealer + 1) % N, sb); post((g.dealer + 2) % N, bb);
    g.cur = bb; g.toAct = (g.dealer + 3) % N;
    g.log.push(`Chia bài. Ghế ${g.dealer} là cái. Mù nhỏ ${sb}, mù lớn ${bb}.`);
    p.wallet -= buyin;
    p.poker = g;
    runBots(p);
}

const pot = (g) => g.total.reduce((a, b) => a + b, 0);
function nextSeat(g, from) { for (let k = 1; k <= N; k++) { const s = (from + k) % N; if (!g.folded[s] && !g.allin[s]) return s; } return -1; }

function roundDone(g) {
    const act = canAct(g);
    if (act.length === 0) return true;
    if (act.length === 1) return g.bets[act[0]] >= g.cur;       // chỉ còn 1 người còn tiền: không còn ai để đấu cược
    return act.every((s) => g.acted[s] && g.bets[s] === g.cur);
}

function afterAction(p, seat) {
    const g = p.poker;
    if (live(g).length === 1) return finish(p);
    if (roundDone(g)) {
        // sang vòng sau
        while (true) {
            if (g.street === 3) return finish(p);
            g.street++;
            if (g.street === 1) { g.deck.pop(); g.board.push(g.deck.pop(), g.deck.pop(), g.deck.pop()); }
            else { g.deck.pop(); g.board.push(g.deck.pop()); }
            g.bets = Array(N).fill(0); g.acted = Array(N).fill(false); g.cur = 0; g.minRaise = g.bb; g.raises = 0;
            if (canAct(g).length >= 2) { g.toAct = nextSeat(g, g.dealer); return; }
            // không ai đấu thêm được: lật hết bài
        }
    }
    g.toAct = nextSeat(g, seat);
}

function apply(p, seat, action, amount) {
    const g = p.poker, to = Math.max(0, g.cur - g.bets[seat]);
    if (action === 'fold') { g.folded[seat] = true; g.log.push(`Ghế ${seat} bỏ bài.`); }
    else if (action === 'call') {
        const a = Math.min(to, g.stacks[seat]); g.stacks[seat] -= a; g.bets[seat] += a; g.total[seat] += a; if (!g.stacks[seat]) g.allin[seat] = true;
        g.acted[seat] = true; g.log.push(a === 0 ? `Ghế ${seat} xem bài.` : `Ghế ${seat} theo ${a}.`);
    } else {                                                   // raise: amount = tổng mức cược mong muốn ở vòng này
        const maxTo = g.bets[seat] + g.stacks[seat];
        let R = Math.min(Math.floor(amount), maxTo);
        if (action === 'allin') R = maxTo;
        if (R < g.cur + g.minRaise && R < maxTo) R = Math.min(g.cur + g.minRaise, maxTo);
        const a = R - g.bets[seat]; g.stacks[seat] -= a; g.bets[seat] += a; g.total[seat] += a; if (!g.stacks[seat]) g.allin[seat] = true;
        if (R > g.cur) {
            if (R - g.cur >= g.minRaise) g.minRaise = R - g.cur;
            g.cur = R; g.raises++;
            g.acted = Array(N).fill(false);
        }
        g.acted[seat] = true; g.log.push(g.allin[seat] ? `Ghế ${seat} tất tay ${R}.` : `Ghế ${seat} tố lên ${R}.`);
    }
    afterAction(p, seat);
}

/* ---------- Bot ---------- */
function preflopStrength(h) {
    const a = rankOf(h[0]), b = rankOf(h[1]), hi = Math.max(a, b), lo = Math.min(a, b), suited = suitOf(h[0]) === suitOf(h[1]);
    let s = (hi + lo) / 28 * 0.5;
    if (a === b) s = 0.55 + a / 14 * 0.45;
    if (suited) s += 0.06;
    if (hi - lo === 1) s += 0.05;
    return Math.min(1, s);
}
function botStrength(g, seat) {
    if (g.board.length === 0) return preflopStrength(g.hole[seat]);
    const sc = best7(g.hole[seat].concat(g.board)), cat = Math.floor(sc / Math.pow(15, 5));
    return [0.2, 0.5, 0.7, 0.8, 0.88, 0.92, 0.96, 0.99, 1][cat];
}
function botAct(p, seat) {
    const g = p.poker, to = Math.max(0, g.cur - g.bets[seat]), pt = pot(g), s = botStrength(g, seat) + (rnd() - 0.5) * 0.25;
    const raiseTo = () => g.cur + Math.max(g.minRaise, Math.round(pt * (0.4 + rnd() * 0.5)));
    if (to === 0) return s > 0.72 && g.raises < 3 ? apply(p, seat, 'raise', raiseTo()) : apply(p, seat, 'call');
    if (s > 0.85 && g.raises < 3) return apply(p, seat, 'raise', raiseTo());
    if (s > 0.5 || to <= pt * 0.12 && rnd() < 0.5 || to >= g.stacks[seat] && s > 0.65) return apply(p, seat, 'call');
    return apply(p, seat, 'fold');
}
function runBots(p) {
    const g = p.poker;
    for (let guard = 0; guard < 80 && g.st === 'play' && g.toAct > 0; guard++) botAct(p, g.toAct);
}

/* ---------- Kết thúc ---------- */
function finish(p) {
    const g = p.poker, alive = live(g), gain = Array(N).fill(0);
    let hands = null;
    if (alive.length === 1) gain[alive[0]] = pot(g);
    else {
        while (g.board.length < 5) { if (g.board.length === 0) g.deck.pop(); else if (g.board.length === 3 || g.board.length === 4) g.deck.pop(); g.board.push(g.deck.pop()); }
        hands = {}; alive.forEach((i) => { hands[i] = best7(g.hole[i].concat(g.board)); });
        const levels = [...new Set(alive.map((i) => g.total[i]))].sort((a, b) => a - b);
        let prev = 0;
        for (const lv of levels) {
            const part = g.total.reduce((a, t) => a + Math.max(0, Math.min(t, lv) - prev), 0);
            const el = alive.filter((i) => g.total[i] >= lv);
            const top = Math.max(...el.map((i) => hands[i])), win = el.filter((i) => hands[i] === top);
            const each = Math.floor(part / win.length); win.forEach((i) => { gain[i] += each; }); gain[win[0]] += part - each * win.length;
            prev = lv;
        }
        // phần cược thừa của người cược cao nhất mà không ai theo: trả lại (đã nằm ở mức cuối nếu chỉ một người đạt mức đó)
    }
    for (let i = 0; i < N; i++) g.stacks[i] += gain[i];
    const net = g.stacks[0] - g.buyin;
    p.wallet += g.stacks[0];
    p.profit = net > 0 ? p.profit + net : Math.max(0, p.profit + net);
    p.pk = p.pk || { n: 0, w: 0 }; p.pk.n++; if (net > 0) p.pk.w++;
    g.st = 'done';
    g.result = { net, gain, showdown: alive.length > 1, names: hands ? Object.fromEntries(alive.map((i) => [i, catOf(hands[i])])) : {}, winners: gain.map((x, i) => (x > 0 ? i : -1)).filter((i) => i >= 0) };
    g.log.push(net > 0 ? `Bạn thắng +${net} vàng.` : net < 0 ? `Bạn thua ${net} vàng.` : 'Hòa vốn.');
    g.toAct = -1;
}

function act(p, action, amount) {
    const g = p.poker;
    if (!g || g.st !== 'play') throw new Error('Bạn chưa vào ván nào.');
    if (g.toAct !== 0) throw new Error('Chưa tới lượt bạn.');
    if (!['fold', 'call', 'raise', 'allin'].includes(action)) throw new Error('Hành động không hợp lệ.');
    if (action === 'raise' && !Number.isFinite(amount)) throw new Error('Nhập mức tố.');
    apply(p, 0, action, amount);
    if (g.st === 'play') runBots(p);
}

/* ---------- Gửi cho người chơi (giấu bài úp) ---------- */
function view(p) {
    const g = p.poker;
    if (!g) return null;
    const done = g.st === 'done', show = done && g.result.showdown;
    return {
        st: g.st, buyin: g.buyin, bb: g.bb, sb: g.sb, dealer: g.dealer, street: g.street, toAct: g.toAct, pot: pot(g), cur: g.cur, minRaise: g.minRaise,
        board: g.board.map(cardStr), stacks: g.stacks, bets: g.bets, folded: g.folded, allin: g.allin,
        hole: g.hole.map((h, i) => (i === 0 || (show && !g.folded[i]) ? h.map(cardStr) : null)),
        toCall: Math.max(0, Math.min(g.cur - g.bets[0], g.stacks[0])), log: g.log.slice(-8), result: g.result,
    };
}

module.exports = { start, act, view, best7, catOf, cardStr, shuffle, MIN_BUYIN, MAX_BUYIN };
