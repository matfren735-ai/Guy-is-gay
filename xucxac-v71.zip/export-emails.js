'use strict';
/**
 * Xuất danh sách email ra file CSV để bạn bán gói tháng / gửi ưu đãi.
 *   node export-emails.js            → chỉ người ĐÃ ĐỒNG Ý nhận ưu đãi (dùng cho quảng bá)
 *   node export-emails.js --all      → tất cả có email (CHỈ dùng gửi thư dịch vụ, không dùng quảng bá)
 * Chạy trên chính máy chủ (không có đường truy cập từ web nên người ngoài không lấy được).
 * Biến DB_FILE giống server. Kết quả in ra màn hình: node export-emails.js > emails.csv
 */
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync(process.env.DB_FILE || path.join(__dirname, 'data.sqlite'));
const all = process.argv.includes('--all');
const rows = db.prepare(
    `SELECT username, email, marketing_ok, terms_at, created_at FROM users
     WHERE email IS NOT NULL ${all ? '' : 'AND marketing_ok = 1'} ORDER BY id`
).all();
const q = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
const iso = (t) => (t ? new Date(t).toISOString() : '');
console.log('username,email,dong_y_quang_ba,ngay_dong_y_dieu_khoan,ngay_dang_ky');
for (const r of rows) console.log([q(r.username), q(r.email), r.marketing_ok, q(iso(r.terms_at)), q(iso(r.created_at))].join(','));
console.error(`Đã xuất ${rows.length} dòng${all ? ' (tất cả)' : ' (chỉ người đồng ý nhận ưu đãi)'}.`);
