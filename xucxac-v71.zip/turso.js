'use strict';
/* Sao lưu SQLite cục bộ lên Turso (HTTP) để dữ liệu không mất khi Render khởi động lại.
   - Khi khởi động: tải bản sao về (đồng bộ, qua tiến trình con) rồi nạp vào SQLite.
   - Khi chạy: cứ 10 giây, bảng nào đổi thì đẩy lên Turso; đẩy nốt khi nhận SIGTERM. */
const { execFileSync } = require('node:child_process');

const RAW = process.env.TURSO_URL || '';
const TOKEN = process.env.TURSO_TOKEN || '';
const enabled = !!(RAW && TOKEN);
const BASE = RAW.replace(/^libsql:\/\//, 'https://').replace(/\/+$/, '');
const TABLES = ['users', 'sessions', 'gifts', 'star_log', 'lb_week','lb_period','ref_claims','news','mp_queue','mp_tables', 'verify_codes', 'reset_tokens', 'pstate', 'settings', 'mail', 'support'];

async function pipeline(stmts) {
    const body = { requests: [...stmts.map((s) => ({ type: 'execute', stmt: {
        sql: s.sql, args: (s.args || []).map((v) => ({ type: 'text', value: String(v) })) } })), { type: 'close' }] };
    const r = await fetch(BASE + '/v2/pipeline', {
        method: 'POST', headers: { Authorization: 'Bearer ' + TOKEN, 'Content-Type': 'application/json' },
        body: JSON.stringify(body), signal: AbortSignal.timeout(20000),
    });
    if (!r.ok) throw new Error('Turso HTTP ' + r.status + ' ' + (await r.text()).slice(0, 200));
    const j = await r.json();
    for (const x of j.results) if (x.type === 'error') throw new Error('Turso: ' + (x.error && x.error.message));
    return j.results;
}

const INIT = { sql: 'CREATE TABLE IF NOT EXISTS snap (k TEXT PRIMARY KEY, v TEXT NOT NULL, at INTEGER)' };

/* Chạy như tiến trình con: in JSON {bảng: [dòng...]} ra stdout */
async function fetchAll() {
    const res = await pipeline([INIT, { sql: 'SELECT k, v FROM snap' }]);
    const out = {};
    for (const row of res[1].response.result.rows) out[row[0].value] = JSON.parse(row[1].value);
    process.stdout.write(JSON.stringify(out));
}

/* Đồng bộ: dùng ở lúc khởi động. Trả về {} nếu chưa có dữ liệu; ném lỗi nếu không kết nối được. */
function restoreSync() {
    if (!enabled) return {};
    const txt = execFileSync(process.execPath, [__filename, '--fetch'], { env: process.env, timeout: 30000, maxBuffer: 256 * 1024 * 1024 }).toString();
    return txt ? JSON.parse(txt) : {};
}

function importInto(db, snap) {
    let n = 0;
    for (const t of TABLES) {
        const rows = snap[t];
        if (!Array.isArray(rows)) continue;
        for (const r of rows) {
            const cols = Object.keys(r);
            db.prepare(`INSERT OR REPLACE INTO ${t} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`).run(...cols.map((c) => r[c]));
            n++;
        }
    }
    return n;
}

function start(db) {
    if (!enabled) return;
    const last = {};
    let busy = false, inited = false;
    async function push(force) {
        if (busy) return; busy = true;
        try {
            const stmts = [];
            if (!inited) stmts.push(INIT);
            const changed = [];
            for (const t of TABLES) {
                const v = JSON.stringify(db.prepare(`SELECT * FROM ${t}`).all());
                if (v !== last[t]) { stmts.push({ sql: 'INSERT OR REPLACE INTO snap (k, v, at) VALUES (?, ?, ?)', args: [t, v, Date.now()] }); changed.push([t, v]); }
            }
            if (changed.length) { await pipeline(stmts); for (const [t, v] of changed) last[t] = v; inited = true; }
        } catch (e) { console.error('Sao lưu Turso lỗi:', e.message); }
        busy = false;
    }
    setInterval(() => push(), 10000).unref();
    let closing = false;
    const bye = async () => { if (closing) return; closing = true; busy = false; await push(true); process.exit(0); };
    process.on('SIGTERM', bye); process.on('SIGINT', bye);
    console.log('Turso: bật sao lưu tự động (10 giây/lần)');
    push();
}

if (require.main === module && process.argv[2] === '--fetch') fetchAll().catch((e) => { console.error(e.message); process.exit(1); });
module.exports = { enabled, restoreSync, importInto, start };
