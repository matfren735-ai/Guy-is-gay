'use strict';
// Poker Texas Hold'em NHIỀU NGƯỜI THẬT (2–4 người/bàn), không bot. Bàn chạy trong bộ nhớ server, mỗi ván tách biệt.
const { best7, catOf, cardStr, shuffle } = require('./poker');
const TURN_MS = 25000;

const live = (g) => g.folded.map((f, i) => (f ? -1 : i)).filter((i) => i >= 0);
const canAct = (g) => live(g).filter((i) => !g.allin[i]);
const pot = (g) => g.total.reduce((a, b) => a + b, 0);
function nextSeat(g, from) { for (let k = 1; k <= g.n; k++) { const s = (from + k) % g.n; if (!g.folded[s] && !g.allin[s]) return s; } return -1; }

function newTable(players, buyin, now) {
    const n = players.length, bb = Math.max(2, Math.round(buyin / 25)), sb = Math.max(1, Math.floor(bb / 2));
    const g = {
        st: 'play', n, players: players.map((x) => ({ id: x.id, name: x.name })), buyin, bb, sb, dealer: Math.floor(Math.random() * n), deck: shuffle(), hole: [], board: [],
        stacks: Array(n).fill(buyin), bets: Array(n).fill(0), total: Array(n).fill(0), folded: Array(n).fill(false), allin: Array(n).fill(false), acted: Array(n).fill(false),
        street: 0, cur: 0, minRaise: bb, toAct: 0, raises: 0, log: [], result: null, deadline: 0, paid: false, left: Array(n).fill(false), timeouts: Array(n).fill(0),
    };
    for (let i = 0; i < n; i++) g.hole.push([g.deck.pop(), g.deck.pop()]);
    const post = (s, amt) => { const a = Math.min(amt, g.stacks[s]); g.stacks[s] -= a; g.bets[s] += a; g.total[s] += a; if (!g.stacks[s]) g.allin[s] = true; };
    // 2 người: cái là mù nhỏ và đi trước; từ 3 người: mù nhỏ/lớn là 2 ghế sau cái
    const sbSeat = n === 2 ? g.dealer : (g.dealer + 1) % n, bbSeat = n === 2 ? (g.dealer + 1) % n : (g.dealer + 2) % n;
    post(sbSeat, sb); post(bbSeat, bb);
    g.cur = bb; g.toAct = n === 2 ? sbSeat : (g.dealer + 3) % n;
    g.log.push(`Chia bài. ${g.players[g.dealer].name} là cái. Mù ${sb}/${bb}.`);
    g.deadline = now + TURN_MS;
    return g;
}

function roundDone(g) {
    const act = canAct(g);
    if (act.length === 0) return true;
    if (act.length === 1) return g.bets[act[0]] >= g.cur;
    return act.every((s) => g.acted[s] && g.bets[s] === g.cur);
}

function afterAction(g, seat, now) {
    if (live(g).length === 1) return finish(g);
    if (roundDone(g)) {
        while (true) {
            if (g.street === 3) return finish(g);
            g.street++;
            if (g.street === 1) { g.deck.pop(); g.board.push(g.deck.pop(), g.deck.pop(), g.deck.pop()); }
            else { g.deck.pop(); g.board.push(g.deck.pop()); }
            g.bets = Array(g.n).fill(0); g.acted = Array(g.n).fill(false); g.cur = 0; g.minRaise = g.bb; g.raises = 0;
            if (canAct(g).length >= 2) { g.toAct = nextSeat(g, g.dealer); g.deadline = now + TURN_MS; return; }
        }
    }
    g.toAct = nextSeat(g, seat); g.deadline = now + TURN_MS;
}

function apply(g, seat, action, amount, now) {
    const to = Math.max(0, g.cur - g.bets[seat]), nm = g.players[seat].name;
    if (action === 'fold') { g.folded[seat] = true; g.log.push(`${nm} bỏ bài.`); }
    else if (action === 'call') {
        const a = Math.min(to, g.stacks[seat]); g.stacks[seat] -= a; g.bets[seat] += a; g.total[seat] += a; if (!g.stacks[seat]) g.allin[seat] = true;
        g.acted[seat] = true; g.log.push(a === 0 ? `${nm} xem bài.` : `${nm} theo ${a}.`);
    } else {
        const maxTo = g.bets[seat] + g.stacks[seat];
        let R = Math.min(Math.floor(amount), maxTo);
        if (action === 'allin') R = maxTo;
        if (R < g.cur + g.minRaise && R < maxTo) R = Math.min(g.cur + g.minRaise, maxTo);
        const a = R - g.bets[seat]; g.stacks[seat] -= a; g.bets[seat] += a; g.total[seat] += a; if (!g.stacks[seat]) g.allin[seat] = true;
        if (R > g.cur) { if (R - g.cur >= g.minRaise) g.minRaise = R - g.cur; g.cur = R; g.raises++; g.acted = Array(g.n).fill(false); }
        g.acted[seat] = true; g.log.push(g.allin[seat] ? `${nm} tất tay ${R}.` : `${nm} tố lên ${R}.`);
    }
    afterAction(g, seat, now);
}

function finish(g) {
    const alive = live(g), gain = Array(g.n).fill(0);
    let hands = null;
    if (alive.length === 1) gain[alive[0]] = pot(g);
    else {
        hands = {}; alive.forEach((i) => { hands[i] = best7(g.hole[i].concat(g.board)); });
        const levels = [...new Set(alive.map((i) => g.total[i]))].sort((a, b) => a - b);
        let prev = 0;
        for (const lv of levels) {
            const part = g.total.reduce((a, t) => a + Math.max(0, Math.min(t, lv) - prev), 0);
            const el = alive.filter((i) => g.total[i] >= lv);
            const top = Math.max(...el.map((i) => hands[i])), win = el.filter((i) => hands[i] === top);
            const each = Math.floor(part / win.length); win.forEach((i) => { gain[i] += each; }); gain[win[0]] += part - each * win.length;
            prev = lv;
        }
    }
    for (let i = 0; i < g.n; i++) g.stacks[i] += gain[i];
    g.st = 'done'; g.toAct = -1;
    g.result = { gain, showdown: alive.length > 1, names: hands ? Object.fromEntries(alive.map((i) => [i, catOf(hands[i])])) : {}, nets: g.stacks.map((s) => s - g.buyin) };
    g.log.push(`Kết thúc. Người thắng: ${gain.map((x, i) => (x > 0 ? g.players[i].name : null)).filter(Boolean).join(', ')}.`);
}

function act(g, seat, action, amount, now) {
    if (g.st !== 'play') throw new Error('Ván đã kết thúc.');
    if (g.toAct !== seat) throw new Error('Chưa tới lượt bạn.');
    if (!['fold', 'call', 'raise', 'allin'].includes(action)) throw new Error('Hành động không hợp lệ.');
    if (action === 'raise' && !Number.isFinite(amount)) throw new Error('Nhập mức tố.');
    g.timeouts[seat] = 0;
    apply(g, seat, action, amount, now);
}
// quá giờ: xem bài nếu được, không thì bỏ bài
function timeoutAct(g, now) {
    if (g.st !== 'play' || now < g.deadline) return false;
    const s = g.toAct; g.timeouts[s]++;
    apply(g, s, g.cur > g.bets[s] ? 'fold' : 'call', 0, now);
    return true;
}
function leave(g, seat, now) {          // người chơi rời bàn giữa ván = bỏ bài
    if (g.st === 'play' && !g.folded[seat]) { if (g.toAct === seat) apply(g, seat, 'fold', 0, now); else { g.folded[seat] = true; g.log.push(`${g.players[seat].name} rời bàn.`); if (live(g).length === 1) finish(g); else if (roundDone(g)) afterAction(g, seat, now); } }
    g.left[seat] = true;
}

function view(g, seat, now) {
    const done = g.st === 'done', show = done && g.result.showdown;
    return {
        st: g.st, n: g.n, me: seat, players: g.players.map((x) => x.name), buyin: g.buyin, bb: g.bb, sb: g.sb, dealer: g.dealer, street: g.street, toAct: g.toAct, pot: pot(g), cur: g.cur, minRaise: g.minRaise,
        board: g.board.map(cardStr), stacks: g.stacks, bets: g.bets, folded: g.folded, allin: g.allin,
        hole: g.hole.map((h, i) => (i === seat || (show && !g.folded[i]) ? h.map(cardStr) : null)),
        toCall: Math.max(0, Math.min(g.cur - g.bets[seat], g.stacks[seat])), log: g.log.slice(-8), result: g.result,
        secsLeft: g.st === 'play' ? Math.max(0, Math.ceil((g.deadline - now) / 1000)) : 0,
    };
}

module.exports = { newTable, act, timeoutAct, leave, view, TURN_MS, finish };
