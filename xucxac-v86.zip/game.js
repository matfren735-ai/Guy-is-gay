'use strict';
/* Luật chơi chạy trên SERVER: vàng, hạng, mưa vàng, nhiệm vụ, skin, code. App chỉ hiển thị kết quả server trả về. */
const crypto = require('crypto');

const ROUND_MS = 60 * 1000, LOCK_MS = 10 * 1000, RED_MAX = 10;
const MIN_STAKE = 1, MAX_STAKE = 1000, STAR_PRICE = 80, RAIN_BONUS = 50;
const VN_OFFSET = 7 * 3600 * 1000;

const RANKS = [
    { name: 'Tân binh', min: 0, mult: 1.0 }, { name: 'Đồng', min: 50, mult: 1.2 }, { name: 'Bạc', min: 88, mult: 1.3 },
    { name: 'Vàng', min: 175, mult: 1.4 }, { name: 'Kim cương', min: 438, mult: 1.5 }, { name: 'Cao thủ', min: 493, mult: 5.0 }
];
const LOSS_FRAC = [0.50, 0.56, 0.62, 0.68, 0.74, 0.80];
const RAIN_BY_RANK = [
    { step: 0.061, grace: 0, cap: 0.30, pmax: 11 }, { step: 0.028, grace: 0, cap: 0.27, pmax: 12 },
    { step: 0.021, grace: 0, cap: 0.26, pmax: 13 }, { step: 0.019, grace: 0, cap: 0.25, pmax: 14 },
    { step: 0.061, grace: 4, cap: 0.30, pmax: 15 }, { step: 0.026, grace: 0, cap: 0.10, pmax: 20 }
];
const DAILY_REWARDS = [10, 15, 20, 25, 30, 40, 80];
const MISSIONS = [
    { id: 'd_play', scope: 'day', stat: 'plays', goal: 10, gold: 15 },
    { id: 'd_win', scope: 'day', stat: 'wins', goal: 5, gold: 20 },
    { id: 'd_str', scope: 'day', stat: 'streak', goal: 3, gold: 25 },
    { id: 'w_play', scope: 'week', stat: 'plays', goal: 60, gold: 80 },
    { id: 'w_win', scope: 'week', stat: 'wins', goal: 30, gold: 100 }
];
const SKINS = { classic: 0, ruby: 60, emerald: 100, ice: 140, sakura: 180, gold: 250, obsidian: 350, neon: 500, rainbow: 'rain3', legend: 'login7', bowl_bronze: 0, bowl_jade: 80, bowl_silver: 120, bowl_ruby: 160, bowl_night: 250 };
const ACHS = [
    { id: 'first_win', test: (p) => p.correct >= 1 }, { id: 'win10', test: (p) => p.correct >= 10 },
    { id: 'win100', test: (p) => p.correct >= 100 }, { id: 'streak5', test: (p) => p.best >= 5 },
    { id: 'streak10', test: (p) => p.best >= 10 }, { id: 'silver', test: (p) => rankIndex(p.profit) >= 2 },
    { id: 'rain3', test: (p) => (p.rainTotal || 0) >= 3, skin: 'rainbow' },
    { id: 'login7', test: (p) => p.daily && p.daily.best >= 7, skin: 'legend' }
];
const ACH_NAMES = { rain3: 'Mưa vàng 3 lần', login7: 'Điểm danh 7 ngày liền' };
// Code thử: dùng không giới hạn trừ khi có "once". Đặt DISABLE_TEST_CODES=1 để tắt hẳn trước khi phát hành.
const CODES = process.env.DISABLE_TEST_CODES === '1' ? {} : {
    test: { gold: 10 }, test100: { gold: 100 }, test1000: { gold: 1000 }, nocode: { gold: -10 },
    newbie100: { gold: 100, once: true, id: 'newbie' }, newbie: { gold: 100, once: true, id: 'newbie' }
};

class GameError extends Error { constructor(msg) { super(msg); this.status = 400; } }

const rankIndex = (profit) => { let i = 0; RANKS.forEach((r, n) => { if (profit >= r.min) i = n; }); return i; };
const rand = () => crypto.randomInt(1e9) / 1e9;
const vnDate = (ms) => new Date(ms + VN_OFFSET);
const dayKey = (ms) => vnDate(ms).toISOString().slice(0, 10);
const weekKey = (ms) => { const d = vnDate(ms); const dow = (d.getUTCDay() + 6) % 7; return new Date(d.getTime() - dow * 86400000).toISOString().slice(0, 10); };
const evMult = (ms) => { const d = vnDate(ms), dow = d.getUTCDay(), h = d.getUTCHours(); return (dow === 6 || dow === 0) && h >= 20 && h < 22 ? 1.5 : 1; };
const rainChance = (ri, n) => { const r = RAIN_BY_RANK[ri]; return n >= r.pmax ? 1 : Math.min(r.cap, Math.max(0, r.step * (n - r.grace))); };
const colorOfSum = (s) => (s <= RED_MAX ? 'RED' : 'GREEN');

function newState(gold) {
    return {
        v: 1, wallet: gold, profit: 0, streak: 0, best: 0, correct: 0, total: 0, rainCount: 0, rainTotal: 0,
        owned: ['classic'], skin: 'classic', usedCodes: {}, daily: { last: '', streak: 0, best: 0 },
        mday: null, mweek: null, ach: {}, pend: [], log: []
    };
}
function ensure(p, now) {
    const dk = dayKey(now), wk = weekKey(now);
    if (!p.mday || p.mday.key !== dk) p.mday = { key: dk, plays: 0, wins: 0, streak: 0, claimed: {} };
    if (!p.mweek || p.mweek.key !== wk) p.mweek = { key: wk, plays: 0, wins: 0, claimed: {} };
}
const reserved = (p, except) => p.pend.reduce((s, e) => s + (e === except ? 0 : e.stake), 0);

/* ===== Điều chỉnh lãi/lỗ theo số dư ví (chống lạm phát vàng) =====
   Mốc đích T = bội kế tiếp của 80 lớn hơn số dư (80, 160, 240, ...). Hệ thống chỉ BẬT khi ví đạt 6/8 (= 75%) của T:
   ví 60 với T=80; ví 120 với T=160; ví 180 với T=240; ... Từ ngưỡng đó tới T:
   - hệ số lãi giảm dần từ x1 xuống tối thiểu x0,2;  - hệ số lỗ tăng dần từ x1 lên tối đa x2.
   Mỗi lần có thêm độ ngẫu nhiên nhỏ, và trong một chu kỳ (cùng T) chỉ giảm (lãi) / chỉ tăng (lỗ). Ví vượt qua T thì tính lại.
   Dưới ngưỡng: lãi x1, lỗ x1 (không can thiệp). Nếu ví tụt xuống dưới ngưỡng rồi lên lại trong cùng chu kỳ thì vẫn không được hồi hệ số (chỉ giảm/tăng).
   Ngoài ra lỗ nhân thêm theo mức cược (cược lớn tới x2) và theo hạng (mỗi hạng nhân thêm 2). */
const SQ_PERIOD = 80, SQ_START = 0.75;                    // ngưỡng bật = 75% của mốc đích (6/8)
const SQ_GAIN_PTS = [[0, 1], [0.25, 0.75], [0.5, 0.55], [0.75, 0.4], [1, 0.2]];   // u = tiến độ trong vùng [ngưỡng, T]
const SQ_LOSS_PTS = [[0, 1], [0.25, 1.25], [0.5, 1.5], [0.75, 1.75], [1, 2]];
const SQ_ON = process.env.GAME_NO_SQUEEZE !== '1';       // chỉ để chạy bài kiểm tra cũ; KHÔNG đặt trên server thật
const interp = (pts, x) => {
    for (let i = 1; i < pts.length; i++) if (x <= pts[i][0]) { const [x0, y0] = pts[i - 1], [x1, y1] = pts[i]; return y0 + (y1 - y0) * (x - x0) / (x1 - x0); }
    return pts[pts.length - 1][1];
};
// Trả về {g, l}: hệ số nhân cho lãi và lỗ ở lần này. Cập nhật p.cyc (chu kỳ hiện tại của ví).
function squeeze(p, rnd) {
    if (!SQ_ON) return { g: 1, l: 1 };
    const r = rnd || rand, T = (Math.floor(p.wallet / SQ_PERIOD) + 1) * SQ_PERIOD;
    if (!p.cyc || p.cyc.T !== T) p.cyc = { T, g: 1, l: 1 };
    const lo = T * SQ_START;
    if (p.wallet < lo) return { g: 1, l: 1 };                         // chưa tới ngưỡng 6/8: không can thiệp
    const u = Math.min(1, (p.wallet - lo) / (T - lo));
    const bg = interp(SQ_GAIN_PTS, u), bl = interp(SQ_LOSS_PTS, u);
    const g = Math.max(0.2, bg - r() * 0.12 * ((1 - bg) / 0.8));
    const l = Math.min(2, bl + r() * 0.2 * (bl - 1));
    p.cyc.g = Math.min(p.cyc.g, g);
    p.cyc.l = Math.max(p.cyc.l, l);
    return { g: p.cyc.g, l: p.cyc.l };
}
const stakeLossMult = (stake) => 1 + Math.min(1, Math.max(0, (stake - 10) / 490));     // cược 10 → x1, cược ≥500 → x2
const rankLossMult = (ri) => (SQ_ON ? Math.pow(2, ri) : 1);                              // mỗi hạng nhân thêm 2
const lossFactor = (stake, ri, sq) => (SQ_ON ? stakeLossMult(stake) : 1) * rankLossMult(ri) * sq.l;

function checkAch(p, events) {
    ACHS.forEach((a) => {
        if (p.ach[a.id] || !a.test(p)) return;
        p.ach[a.id] = Date.now();
        if (a.skin && !p.owned.includes(a.skin)) p.owned.push(a.skin);
        events.push(`🏆 Thành tựu mới${a.skin ? ': mở khóa skin ' + a.skin : ''}`);
    });
}

// Chấm mọi lựa chọn của các ván đã kết thúc (k < cur). dice(room,k) → [x1,x2,x3]. onWin(): đếm bảng xếp hạng tuần.
function settle(p, cur, dice, now, onWin) {
    ensure(p, now);
    const outcomes = [];
    p.pend.sort((a, b) => a.k - b.k);
    const keep = [];
    for (const e of p.pend) {
        if (e.k >= cur) { keep.push(e); continue; }
        const d = dice(e.room, e.k), sum = d[0] + d[1] + d[2];
        const before = rankIndex(p.profit);
        const win = e.color === colorOfSum(sum);
        let gain = 0, loss = 0, rain = 0;
        p.total++; p.mday.plays++; p.mweek.plays++;
        const sq = squeeze(p);
        if (win) {
            gain = Math.max(1, Math.round(e.stake * RANKS[before].mult * evMult((e.k + 1) * ROUND_MS) * sq.g));
            p.wallet += gain;
            p.rainCount = (p.rainCount || 0) + 1;
            if (rand() < rainChance(before, p.rainCount)) { rain = e.stake * RAIN_BONUS; p.wallet += rain; p.rainCount = 0; p.rainTotal++; }
            p.profit += gain + rain;
            p.correct++; p.streak++; p.best = Math.max(p.best, p.streak);
            p.mday.wins++; p.mweek.wins++; p.mday.streak = Math.max(p.mday.streak, p.streak);
            if (onWin) onWin();
        } else {
            p.streak = 0;
            loss = Math.max(0, Math.min(Math.max(1, Math.round(e.stake * LOSS_FRAC[before] * lossFactor(e.stake, before, sq))), p.wallet));
            p.wallet -= loss;
            p.profit = Math.max(0, p.profit - loss);
        }
        const after = rankIndex(p.profit);
        p.log.push({ room: e.room, k: e.k, color: e.color, stake: e.stake });
        outcomes.push({ k: e.k, room: e.room, picked: e.color, win, stake: e.stake, gain, loss, rain, rankUp: after > before ? after : null, rankDown: after < before ? after : null, sum });
    }
    p.pend = keep;
    if (p.log.length > 80) p.log = p.log.slice(-80);
    // số dư không còn đủ cho mức cược đang chờ → huỷ lựa chọn đó
    p.pend = p.pend.filter((e) => p.wallet >= e.stake);
    const events = [];
    checkAch(p, events);
    return { outcomes, events };
}

// color = 'RED' | 'GREEN' | null (bỏ chọn)
function pick(p, room, cur, color, stake, now) {
    ensure(p, now);
    const remain = (cur + 1) * ROUND_MS - now;
    if (remain <= LOCK_MS) throw new GameError('Ván đã khoá, không đổi lựa chọn được.');
    const same = p.pend.find((e) => e.k === cur && e.room === room);
    if (color === null) { p.pend = p.pend.filter((e) => e !== same); return; }
    if (color !== 'RED' && color !== 'GREEN') throw new GameError('Màu không hợp lệ.');
    if (!Number.isInteger(stake) || stake < MIN_STAKE || stake > MAX_STAKE) throw new GameError(`Mức cược từ ${MIN_STAKE} đến ${MAX_STAKE}.`);
    if (stake > p.wallet - reserved(p, same)) throw new GameError('Không thể cược quá số dư.');
    if (same) { same.color = color; same.stake = stake; } else p.pend.push({ room, k: cur, color, stake });
}

/* ===== Vòng quay may mắn: 14 ô (5 phạt đỏ + 9 thưởng xanh), xếp lộn xộn. Server quay, client chỉ vẽ ô trúng. =====
   Ô trúng: 50% đỏ / 50% xanh. Trong mỗi màu, ô lớn hiếm hơn ô nhỏ (kỳ vọng ≈ hoà vốn). */
const WHEEL_CELLS = [1, -2, 4, -1, 1.5, 6.1, -2.5, 2, 8, -1.5, 2.5, -5, 5, 6.2];
const WHEEL_W = { 1: 30, 1.5: 22, 2: 16, 2.5: 12, 4: 8, 5: 6, 6.1: 3, 6.2: 2, 8: 1, '-1': 18, '-1.5': 22, '-2': 25, '-2.5': 20, '-5': 15 };
const WHEEL_COOLDOWN_MS = 2500;
// Xác suất trúng ô xanh theo hạng: hạng càng cao càng thấp. Tài khoản thử (fair) luôn 50/50.
const WHEEL_GREEN_BY_RANK = [0.50, 0.48, 0.46, 0.44, 0.42, 0.30];
// Chuỗi xanh liên tiếp: 3 lần → tối đa 35%, 5 lần trở lên → tối đa 15% (lấy mức thấp hơn giữa hạng và chuỗi)
const wheelStreakCap = (n) => (n >= 5 ? 0.15 : n >= 3 ? 0.35 : 1);
const wheelGreen = (p, fair) => (fair ? 0.5 : Math.min(WHEEL_GREEN_BY_RANK[rankIndex(p.profit)], wheelStreakCap((p.wheel && p.wheel.gs) || 0)));
function spinWheel(p, stake, now, rnd, fair) {
    const r = rnd || rand;
    ensure(p, now);
    if (!Number.isInteger(stake) || stake < MIN_STAKE || stake > MAX_STAKE) throw new GameError(`Mức cược từ ${MIN_STAKE} đến ${MAX_STAKE}.`);
    if (stake > p.wallet - reserved(p, null)) throw new GameError('Không thể cược quá số dư.');
    if (now - (p.wheelAt || 0) < WHEEL_COOLDOWN_MS) throw new GameError('Quay chậm lại một chút.');
    p.wheelAt = now;
    const green = r() < wheelGreen(p, fair);
    const idxs = WHEEL_CELLS.map((m, i) => i).filter((i) => (WHEEL_CELLS[i] > 0) === green);
    const total = idxs.reduce((s, i) => s + WHEEL_W[String(WHEEL_CELLS[i])], 0);
    let x = r() * total, cell = idxs[idxs.length - 1];
    for (const i of idxs) { x -= WHEEL_W[String(WHEEL_CELLS[i])]; if (x < 0) { cell = i; break; } }
    const mult = WHEEL_CELLS[cell];
    let delta;
    const sq = squeeze(p, r), ri = rankIndex(p.profit);
    if (mult > 0) { delta = Math.max(1, Math.round(stake * mult * sq.g)); p.wallet += delta; p.profit += delta; }
    else { delta = -Math.min(Math.max(1, Math.round(stake * -mult * lossFactor(stake, ri, sq))), p.wallet); p.wallet += delta; p.profit = Math.max(0, p.profit + delta); }
    p.wheel = p.wheel || { n: 0, gs: 0 };
    p.wheel.n++;
    p.wheel.gs = mult > 0 ? (p.wheel.gs || 0) + 1 : 0;
    const events = [];
    checkAch(p, events);
    return { wheel: { cell, mult, stake, delta, gs: p.wheel.gs }, events };
}

function claimDaily(p, now) {
    ensure(p, now);
    const today = dayKey(now), yest = dayKey(now - 86400000), dl = p.daily;
    if (dl.last === today) throw new GameError('Hôm nay bạn đã điểm danh rồi.');
    const alive = dl.last === yest;
    dl.streak = (alive ? dl.streak : 0) + 1;
    dl.best = Math.max(dl.best || 0, dl.streak);
    dl.last = today;
    const gold = DAILY_REWARDS[(dl.streak - 1) % 7];
    p.wallet += gold;
    const events = [`📅 Điểm danh ngày ${dl.streak}: +${gold} vàng`];
    checkAch(p, events);
    return events;
}
function claimMission(p, id, now) {
    ensure(p, now);
    const m = MISSIONS.find((x) => x.id === id);
    if (!m) throw new GameError('Nhiệm vụ không tồn tại.');
    const box = m.scope === 'day' ? p.mday : p.mweek;
    if (box.claimed[id]) throw new GameError('Đã nhận rồi.');
    if ((box[m.stat] || 0) < m.goal) throw new GameError('Chưa hoàn thành nhiệm vụ.');
    box.claimed[id] = true;
    p.wallet += m.gold;
    return [`🎯 Hoàn thành nhiệm vụ: +${m.gold} vàng`];
}
function useSkin(p, id) {
    if (!Object.prototype.hasOwnProperty.call(SKINS, id)) throw new GameError('Skin không tồn tại.');
    const price = SKINS[id];
    const fld = id.startsWith('bowl_') ? 'bowl' : 'skin';
    if (p.owned.includes(id)) { p[fld] = id; return; }
    if (typeof price !== 'number') throw new GameError('Skin sự kiện chỉ nhận được khi mở khóa thành tựu.');
    if (p.wallet - reserved(p, null) < price) throw new GameError('Không đủ vàng.');
    p.wallet -= price; p.owned.push(id); p[fld] = id;
}
function redeemCode(p, key) {
    key = String(key || '').trim().toLowerCase().replace(/\s+/g, '');
    if (!Object.prototype.hasOwnProperty.call(CODES, key)) throw new GameError('Code không hợp lệ.');
    const c = CODES[key];
    if (c.once && p.usedCodes[c.id]) throw new GameError('Code này đã được sử dụng (mỗi code chỉ dùng 1 lần).');
    const before = p.wallet;
    p.wallet = Math.max(0, p.wallet + c.gold);
    if (c.once) p.usedCodes[c.id] = true;
    p.pend = p.pend.filter((e) => p.wallet >= e.stake);
    return p.wallet - before;
}
// Trừ vàng khi mua sao (server cộng sao riêng)
function spendForStars(p, qty) {
    const cost = qty * STAR_PRICE;
    if (p.wallet - reserved(p, null) < cost) throw new GameError('Không đủ vàng.');
    p.wallet -= cost;
}

// Dữ liệu gửi cho app (phần của phòng đang chơi)
function view(p, room) {
    const picks = {}, stakes = {}, resolved = {};
    p.log.forEach((e) => { if (e.room === room) { picks[e.k] = e.color; stakes[e.k] = e.stake; resolved[e.k] = true; } });
    p.pend.forEach((e) => { if (e.room === room) { picks[e.k] = e.color; stakes[e.k] = e.stake; } });
    const r = reserved(p, null);
    return {
        wallet: p.wallet, reserved: r, profit: p.profit, streak: p.streak, best: p.best, correct: p.correct, total: p.total,
        rainCount: p.rainCount, rainTotal: p.rainTotal, owned: p.owned, skin: p.skin, bowl: p.bowl || 'bowl_bronze', daily: p.daily, mday: p.mday, mweek: p.mweek,
        ach: p.ach, picks, stakes, resolved
    };
}

module.exports = {
    reservedGold: (p) => reserved(p, null),
    ROUND_MS, LOCK_MS, STAR_PRICE, GameError, newState, ensure, settle, pick, claimDaily, claimMission, useSkin, redeemCode, spendForStars, view,
    rankIndex, colorOfSum, CODES, spinWheel, WHEEL_CELLS, squeeze, stakeLossMult, rankLossMult, wheelGreen, WHEEL_GREEN_BY_RANK
};
